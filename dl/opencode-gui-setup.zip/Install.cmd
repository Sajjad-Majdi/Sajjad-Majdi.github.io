@echo off
rem Double-click entry point for the opencode gui installer.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" %*
echo.
pause
