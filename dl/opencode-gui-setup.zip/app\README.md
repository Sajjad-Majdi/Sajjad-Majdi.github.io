# opencode gui

A light web UI for opencode. Start it with:

```
opencode gui
```

It starts a headless `opencode serve`, opens http://127.0.0.1:7788, and shuts the
server down when you stop it (Ctrl+C). Running the command again just opens the
tab of the instance that is already up.

Flags: `--port <n>`, `--hostname <h>`, `--no-open`, `--attach <url>` (use a server
you already run), `--cwd <dir>`.

## Install on another machine

`Executables/opencode-gui-setup.zip` is the whole thing. On the target machine
opencode must already work in the terminal, and Node 18+ must be on PATH.

Unzip it, then double-click `Install.cmd` (or run
`powershell -ExecutionPolicy Bypass -File install.ps1`). It copies the app to
`%LOCALAPPDATA%\Programs\opencode-gui`, writes an `opencode` shim next to it,
and puts that shim first on the user PATH. Open a new terminal and run
`opencode gui`. Everything that is not `gui` goes straight to the real
opencode, whose path the installer resolves and bakes into the shim.

`opencode-gui` is the same command under a name that cannot be shadowed, for
the case where another opencode still answers first on PATH.

To uninstall:
`powershell -ExecutionPolicy Bypass -File "%LOCALAPPDATA%\Programs\opencode-gui\uninstall.ps1"`.

Rebuild the package after changing the source with
`Source Code/installer/build.ps1`.

## What it does

- Lists every session by name, newest activity first, with a live status dot and
  a delete button on each row. A working session turns its dot into a slow green
  ring. Nothing is said in words there, and nothing is said in the header
  either: the running commentary belongs in the chat, where the work is, and
  saying it twice only makes the header flicker. The list collapses out of the
  way (Ctrl+B).
- A session whose folder has been deleted or renamed is marked "folder gone" in
  the list, and its path is struck through in the header. opencode fails every prompt in a folder that is
  not there, with an error that names nothing, so the GUI checks first: a folder
  that has gone is never offered, never remembered, and never sent.
- Streams each session live. A turn's work — thinking, tool calls, the running
  commentary — collapses into one line that says what the agent is doing right
  now; open it for the whole chain in order. The answer sits below it.
  Inside the chain each entry hangs off a gutter rule, and the mark on the rule
  carries its state, so it reads in either theme.
- "New session" opens an empty chat, not a dialog. Folder, model (searchable),
  thinking level and agent are chips inside the message box; the session is created
  when you send the first message.
- On an open session the same chips switch model, thinking level and agent live.
- Thinking levels come from the provider config, so a model that offers low /
  medium / high reasoning effort offers them here. The last model, level, agent
  and folder are remembered for the next new chat.
- Approvals appear in the stream. opencode stops and asks before touching
  anything outside the session folder; allow once, always allow, or deny — the
  session list marks any session waiting on you.
- Attach files and images by button, drag-drop or paste; images preview inline.
- Dark and light theme, full RTL support for Persian text.

While the agent is working the send button becomes a stop button — one control,
in the place your hand already is. `Esc` in the message box does the same.

Shortcuts: `Ctrl+N` new chat, `Ctrl+K` search, `Ctrl+M` model picker, `Ctrl+B` sidebar,
`Enter` send, `Shift+Enter` newline, `Esc` stop.

## Layout

```
server.mjs          node server: spawns opencode, proxies /oc/* , serves the UI
public/index.html   markup
public/style.css    theme + components
public/src/         the client, as modules (see below)
public/fonts        Inter, JetBrains Mono, Vazirmatn (self-hosted)
public/vendor       lucide icons, KaTeX
installer/          install.ps1, uninstall.ps1, build.ps1 - the setup package
```

### The client

One store holds the state, one bus carries every change, services talk to the
server, and each component draws from the store. A component never reaches into
another component's DOM, and no module imports the one that imports it — so a
change to how something looks stays inside one file.

```
src/main.js             boot: load, mount, connect, then get out of the way
src/core/
  bus.js                publish/subscribe — the only way a change travels
  store.js              the state, its readers, and the mutators that announce
  api.js                /oc/api (v2), /oc (v1), /gui — one error shape
  dom.js                $, escaping, the frame scheduler everything paints on
  format.js             times, sizes, titles, paths, the shape of an abort
  markdown.js           safe Markdown + LaTeX, offline
src/services/           talk to the server, write the store, draw nothing
  sessions.js           list, open, prompt, interrupt, rewind, approvals
  stream.js             the SSE connection: events in, store changes + signals out
  catalog.js            models, thinking levels, agents, recent folders
  prefs.js              everything kept in localStorage, in one place
  uploads.js  dirs.js   attachments; folder lookups
src/ui/                 components; each mounts once and subscribes
  sidebar.js header.js composer.js pickers.js draft.js folderpicker.js
  attachments.js popover.js toast.js theme.js lightbox.js shortcuts.js
  actions.js            delete, rename, stop, reconcile — from wherever asked
  titles.js watchdog.js the two things that wait and then correct the record
  log/                  the conversation
    view.js             opening a session: replay, then live
    dom.js entries.js   rows, scrolling, streamed text, marginal entries
    turn.js             one turn of work, collapsed to a line
    live.js history.js  the event renderer, and the old message store
    approvals.js        permission and question cards
    edit.js             copy, and edit-from-here (rewind)
```

`bin` is first on the user PATH; anything that is not `gui` goes straight to the
real `opencode` in `%APPDATA%\npm`.
