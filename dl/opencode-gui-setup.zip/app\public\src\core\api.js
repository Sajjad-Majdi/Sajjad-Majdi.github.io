/* HTTP to the node server in front of opencode.

   /oc/api  is opencode's v2 API, /oc is v1, /gui/* is this server's own.
   One reader for all three, so an error always arrives as an Error with the
   server's own message in it. */

export async function req(path, opts) {
  const r = await fetch(path, opts);
  const txt = await r.text();
  let data = null;
  try { data = txt ? JSON.parse(txt) : null; } catch { data = { raw: txt }; }
  if (!r.ok) {
    const msg = (data && (data.message || data.data?.message || data.error)) || txt.slice(0, 260) || r.status;
    throw new Error(String(msg));
  }
  return data;
}

export const v2 = (p, opts) => req("/oc/api" + p, opts);
export const v1 = (p, opts) => req("/oc" + p, opts);
export const gui = (p, opts) => req("/gui" + p, opts);

export const post = (p, body, method = "POST") =>
  v2(p, {
    method,
    headers: { "content-type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });

export const json = (body) => ({
  method: "POST",
  headers: { "content-type": "application/json" },
  body: JSON.stringify(body),
});
