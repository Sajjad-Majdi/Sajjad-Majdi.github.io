/* A tiny publish/subscribe bus.

   Everything that is interesting to more than one part of the app travels
   through here: state changes, live events from the server, one-off signals.
   A component says what it cares about; nothing has to know who is listening.
   That is what keeps the modules from importing each other in circles. */

const listeners = new Map();

export function on(topic, fn) {
  let set = listeners.get(topic);
  if (!set) listeners.set(topic, (set = new Set()));
  set.add(fn);
  return () => off(topic, fn);
}

export function off(topic, fn) {
  listeners.get(topic)?.delete(fn);
}

export function once(topic, fn) {
  const stop = on(topic, (payload) => { stop(); fn(payload); });
  return stop;
}

/* A listener that throws must not stop the others, nor the caller. */
export function emit(topic, payload) {
  const set = listeners.get(topic);
  if (!set) return;
  for (const fn of [...set]) {
    try { fn(payload); } catch (e) { console.error("bus:" + topic, e); }
  }
}

export const bus = { on, off, once, emit };
export default bus;
