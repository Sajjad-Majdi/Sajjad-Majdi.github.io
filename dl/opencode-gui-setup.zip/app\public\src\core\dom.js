/* Element lookup, escaping, and the two schedulers the whole UI paints on. */

export const $ = (id) => document.getElementById(id);

export const esc = (s) =>
  String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* Events arrive faster than a screen refresh. Rebuilding a list per event is
   what made a fast agent look slow, so painting coalesces onto the next frame. */
export function coalesce(fn) {
  let tick = 0;
  return () => {
    if (tick) return;
    tick = requestAnimationFrame(() => { tick = 0; fn(); });
  };
}

export const icons = coalesce(() => {
  try { window.lucide?.createIcons(); } catch {}
});

export function el(tag, cls, html) {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (html != null) node.innerHTML = html;
  return node;
}
