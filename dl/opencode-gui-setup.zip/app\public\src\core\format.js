/* Turning values into the words the interface shows. */

export const baseName = (p) =>
  String(p || "").replace(/[\\/]+$/, "").split(/[\\/]/).pop() || String(p || "");

export const parentName = (x) =>
  baseName(String(x).replace(/[\/]+$/, "").replace(/[\/][^\/]+$/, ""));

export const fmtBytes = (n) =>
  n < 1024 ? n + " B" : n < 1048576 ? (n / 1024).toFixed(1) + " KB" : (n / 1048576).toFixed(1) + " MB";

export const isImage = (n) => /\.(png|jpe?g|gif|webp|bmp|svg|avif)$/i.test(n || "");

export const modelKey = (m) => (m ? m.providerID + "/" + (m.id || m.modelID) : "");

export const clip = (s, n = 20000) => (s.length > n ? s.slice(0, n) + "\n… truncated" : s);

export function ago(t) {
  if (!t) return "";
  const d = Date.now() - t;
  if (d < 45000) return "now";
  if (d < 3600000) return Math.round(d / 60000) + "m";
  if (d < 86400000) return Math.round(d / 3600000) + "h";
  if (d < 604800000) return Math.round(d / 86400000) + "d";
  return new Date(t).toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

/* opencode names a fresh session "New session - <ISO timestamp>" until the model
   writes a real one. Never show that raw stamp — the relative time already says when. */
export const STAMP_TITLE = /^new session\s*[-–—]?\s*\d{4}-\d{2}-\d{2}t[\d:.]+z?$/i;
export function titleOf(s) {
  const t = (s?.title || "").trim();
  return !t || STAMP_TITLE.test(t) ? "Untitled session" : t;
}

/* A local file: attachment is read back through the server, not the page. */
export function localSrc(uri) {
  if (!uri) return "";
  if (/^file:\/\//i.test(uri)) {
    const p = decodeURIComponent(uri.replace(/^file:\/\/\/?/i, ""));
    return "/gui/file?path=" + encodeURIComponent(p);
  }
  return uri;
}

/* The one argument worth showing on a collapsed tool line. */
export function argOf(input) {
  if (!input || typeof input !== "object") return "";
  const p = input.filePath || input.path || input.command || input.pattern ||
            input.query || input.url || input.description || input.prompt;
  if (typeof p === "string") return p.replace(/\s+/g, " ").slice(0, 180);
  return JSON.stringify(input).slice(0, 180);
}

/* Stopping the agent is a decision, not a fault. opencode reports it through the
   same error channel as a real failure, so read the shape and say which it was. */
export function isAbort(err) {
  if (!err) return false;
  const name = err.name || err.type || "";
  const msg = err.message || err.data?.message || "";
  return /abort/i.test(name) || /\b(interrupt|interrupted|aborted|cancell?ed)\b/i.test(msg);
}
