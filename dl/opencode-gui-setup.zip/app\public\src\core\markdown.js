/* Rich text: safe Markdown + LaTeX, offline, no dependencies.

   Code and math are lifted out first, so formatting never touches them.
   Everything else is escaped, then only our own tags are inserted. */

import { esc } from "./dom.js";

const MD_HOLE = "\0";
export function mdRender(src) {
  const holes = [];
  const stash = (html) => { holes.push(html); return MD_HOLE + (holes.length - 1) + MD_HOLE; };
  let t = String(src ?? "");
  if (!t.trim()) return "";
  // fenced code blocks
  t = t.replace(/^```([\w+-]*)\s*\n([\s\S]*?)^```[ \t]*$/gm,
    (m, lang, code) => stash(`<pre class="md-pre" dir="ltr"><code>${esc(code.replace(/\n+$/, ""))}</code></pre>`));
  // inline code
  t = t.replace(/`([^`\n]+?)`/g, (m, code) => stash(`<code class="md-code">${esc(code)}</code>`));
  // math: $$..$$, \[..\], \(..\), $..$ (no currency: $ needs non-digit neighbours)
  const math = (latex, display) => {
    const raw = String(latex || "").trim();
    if (!raw) return "";
    try {
      if (typeof window !== "undefined" && window.katex) return stash(window.katex.renderToString(raw, { displayMode: display, throwOnError: false, strict: false }));
    } catch {}
    return stash(`<code class="md-code">${esc(raw)}</code>`);
  };
  t = t.replace(/\$\$([\s\S]+?)\$\$/g, (m, l) => math(l, true));
  t = t.replace(/\\\[([\s\S]+?)\\\]/g, (m, l) => math(l, true));
  t = t.replace(/\\\(([\s\S]+?)\\\)/g, (m, l) => math(l, false));
  t = t.replace(/(^|[^\d\w$])\$(?!\s)([^$\n]*?)(?<!\s)\$(?![\d])/g, (m, pre, l) => pre + math(l, false));
  // escape everything left (holes survive: U+E000 + digits)
  t = esc(t);
  // links, then autolinks (not inside the href just made, not inside (..) )
  t = t.replace(/\[([^\]\n]+?)\]\(([^)\s]+?)(?:\s+"[^"\n]*")?\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  t = t.replace(/(?<![\"'=(\]])(https?:\/\/[^\s<.,!?:;)\]}]+)/g, '<a href="$1" target="_blank" rel="noopener">$1</a>');
  // emphasis (intraword _ stays literal, so paths survive)
  t = t.replace(/\*\*\*([^*\n]+?)\*\*\*/g, "<strong><em>$1</em></strong>");
  t = t.replace(/\*\*([^*\n]+?)\*\*/g, "<strong>$1</strong>");
  t = t.replace(/__([^_\n]+?)__/g, "<strong>$1</strong>");
  t = t.replace(/(^|[^*\w])\*([^*\n]+?)\*/g, "$1<em>$2</em>");
  t = t.replace(/(?<![\w])_([^_\n]+?)_(?![\w])/g, "<em>$1</em>");
  t = t.replace(/~~([^~\n]+?)~~/g, "<del>$1</del>");
  // blocks
  const lines = t.split("\n");
  const out = [];
  let para = [];
  const flush = () => { if (para.length) { out.push("<p>" + para.join("<br>") + "</p>"); para = []; } };
  const holeAt = (l) => {
    const m = new RegExp("^" + MD_HOLE + "(\\d+)" + MD_HOLE + "$").exec(l);
    return m ? holes[+m[1]] : null;
  };
  const isList = (l) => /^\s*([-*+]\s+|\d+[.)]\s+)/.test(l);
  const isTableSep = (l) => l.includes("|") && /^[\s|:~-]+$/.test(l) && l.includes("-");
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (!line.trim()) { flush(); i++; continue; }
    const hole = holeAt(line);
    if (hole !== null) { flush(); out.push(hole); i++; continue; }
    const h = /^(#{1,6})\s+(.*)$/.exec(line);
    if (h) { flush(); out.push(`<h${h[1].length}>${h[2].trim() || "&nbsp;"}</h${h[1].length}>`); i++; continue; }
    if (/^\s*(---|\*\*\*|___)\s*$/.test(line)) { flush(); out.push("<hr>"); i++; continue; }
    if (/^&gt;\s?/.test(line)) {
      flush();
      const inner = [];
      while (i < lines.length && /^&gt;\s?/.test(lines[i])) { inner.push(lines[i].replace(/^&gt;\s?/, "")); i++; }
      out.push("<blockquote>" + inner.filter((l) => l.trim()).map((l) => `<p>${l}</p>`).join("") + "</blockquote>");
      continue;
    }
    if (isList(line)) {
      flush();
      const ordered = /^\s*\d+[.)]\s+/.test(line);
      const items = [];
      while (i < lines.length && isList(lines[i])) { items.push(lines[i].replace(/^\s*([-*+]|\d+[.)])\s+/, "")); i++; }
      out.push((ordered ? "<ol>" : "<ul>") + items.map((x) => `<li>${x}</li>`).join("") + (ordered ? "</ol>" : "</ul>"));
      continue;
    }
    if (line.includes("|") && i + 1 < lines.length && isTableSep(lines[i + 1])) {
      flush();
      const cells = (l) => l.trim().replace(/^\||\|$/g, "").split("|").map((c) => c.trim());
      const head = cells(line);
      i += 2;
      const rows = [];
      while (i < lines.length && lines[i].includes("|") && lines[i].trim()) { rows.push(cells(lines[i])); i++; }
      out.push("<table><thead><tr>" + head.map((c) => `<th>${c}</th>`).join("") + "</tr></thead><tbody>" +
        rows.map((r) => "<tr>" + r.map((c) => `<td>${c}</td>`).join("") + "</tr>").join("") + "</tbody></table>");
      continue;
    }
    para.push(line);
    i++;
  }
  flush();
  const html = `<div class="md" dir="auto">${out.join("")}</div>`
    .replace(new RegExp(MD_HOLE + "(\\d+)" + MD_HOLE, "g"), (m, n) => holes[+n] ?? "");
  return html;
}
export function finishText(el, raw) {
  if (!el || !el.isConnected) return;
  const s = String(raw ?? "");
  if (!s.trim()) return;
  try { el.innerHTML = mdRender(s); }
  catch { el.textContent = s; }
}

