/* The one place the app keeps what it knows.

   Nothing writes to these fields from the outside: every change goes through a
   mutator here, and every mutator announces itself on the bus. A view never
   asks "did anything change?" — it subscribes to the topic it draws from and
   redraws when it is told to. */

import bus from "./bus.js";

export const T = {
  sessions: "state:sessions",   // the session list, or one session's record
  status: "state:status",       // who is working, and on what
  current: "state:current",     // which session is open
  asking: "state:asking",       // sessions waiting on an answer
  filter: "state:filter",       // sidebar search / scope
  draft: "state:draft",         // the unsent new session
  attachments: "state:attachments",
  catalog: "state:catalog",     // models and agents
};

export const state = {
  sessions: new Map(),   // id -> session record
  status: new Map(),     // id -> "busy" | "retry" | ...
  activity: new Map(),   // id -> what it is doing right now
  touched: new Map(),    // id -> when we last saw it move
  asking: new Map(),     // id -> open questions/permissions
  models: [],
  agents: [],
  info: {},              // /gui/info
  cur: null,             // open session id
  scope: "all",
  filter: "",
  pinned: true,          // the log follows the live end
  attachments: [],
  dirMatches: null,      // folder-name lookup in flight
  editing: null,         // the message row being edited
  nodes: new Map(),      // key -> live DOM node in the log
  turn: null,            // the chain of work behind the answer being written
  draft: null,           // { dir, model, variant, agent }
  revertTs: 0,
  missingDirs: new Set(),   // session folders the server says are not there
};

/* ---------------------------------------------------------------- reads */

/* The API says "running" on /session/active and "busy" on the status event.
   Anything that is not idle means the agent is working. */
export const statusOf = (id) => state.status.get(id) || "idle";
export const isBusy = (id) => statusOf(id) !== "idle" && statusOf(id) !== "retry";
export const isWorking = (id) => statusOf(id) !== "idle";
export const isAsking = (id) => (state.asking.get(id) || 0) > 0;
export const activityOf = (id) => state.activity.get(id);
export const sessionOf = (id) => state.sessions.get(id);
export const currentSession = () => state.sessions.get(state.cur);
export const lastActivity = (s) =>
  Math.max(state.touched.get(s.id) || 0, s.time?.updated || 0, s.time?.created || 0);

/* ---------------------------------------------------------------- writes */

/* A folder that is gone breaks every session that points at it, so the list
   and the header both say so. */
export function markDir(dir, exists) {
  if (!dir) return;
  const had = state.missingDirs.has(dir);
  if (exists) state.missingDirs.delete(dir);
  else state.missingDirs.add(dir);
  if (had !== state.missingDirs.has(dir)) bus.emit(T.sessions);
}
export const dirOf = (s) => s?.location?.directory || s?.directory || "";
export const isDirGone = (s) => {
  const d = dirOf(s);
  return !!d && state.missingDirs.has(d);
};

export function setInfo(info) {
  state.info = info || {};
}

export function setSessions(list) {
  state.sessions.clear();
  for (const s of list || []) state.sessions.set(s.id, s);
  bus.emit(T.sessions);
}
export function putSession(s) {
  if (!s?.id) return;
  state.sessions.set(s.id, s);
  bus.emit(T.sessions, s.id);
}
export function patchSession(id, patch) {
  const s = state.sessions.get(id);
  if (!s) return null;
  Object.assign(s, patch);
  state.sessions.set(id, s);
  bus.emit(T.sessions, id);
  return s;
}
export function dropSession(id) {
  state.sessions.delete(id);
  state.status.delete(id);
  state.activity.delete(id);
  state.touched.delete(id);
  state.asking.delete(id);
  bus.emit(T.sessions, id);
  bus.emit(T.status, id);
}

export function touch(id) {
  if (id) state.touched.set(id, Date.now());
}

export function setStatus(id, type, activity) {
  if (!id) return;
  const before = state.status.get(id);
  state.status.set(id, type);
  if (activity !== undefined) {
    if (activity) state.activity.set(id, activity);
    else state.activity.delete(id);
  }
  if (type === "idle") state.activity.delete(id);
  if (before !== type || activity !== undefined) bus.emit(T.status, id);
}
export function setActivity(id, what) {
  if (!id) return;
  if (what) state.activity.set(id, what);
  else state.activity.delete(id);
  bus.emit(T.status, id);
}
export function clearStatus(id) {
  state.status.delete(id);
  state.activity.delete(id);
  bus.emit(T.status, id);
}
/* /session/active is the authority on who is working. Events can be missed —
   an interrupt, a dropped stream — so this replaces rather than accumulates. */
export function replaceStatus(next) {
  let changed = next.size !== state.status.size;
  if (!changed) for (const [k, v] of next) if (state.status.get(k) !== v) { changed = true; break; }
  if (!changed) return false;
  for (const id of [...state.status.keys()]) {
    if (!next.has(id)) { state.status.delete(id); state.activity.delete(id); }
  }
  for (const [id, v] of next) state.status.set(id, v);
  bus.emit(T.status);
  return true;
}

export function setCurrent(id) {
  if (state.cur === id) return;
  state.cur = id;
  bus.emit(T.current, id);
}
export const isCurrent = (id) => !!id && id === state.cur;

export function bumpAsking(id, delta) {
  if (!id) return;
  const n = Math.max(0, (state.asking.get(id) || 0) + delta);
  if (n) state.asking.set(id, n);
  else state.asking.delete(id);
  bus.emit(T.asking, id);
}
export function setAsking(id, n) {
  if (!id) return;
  if (n) state.asking.set(id, n);
  else state.asking.delete(id);
  bus.emit(T.asking, id);
}

export function setFilter(text) {
  state.filter = text;
  bus.emit(T.filter);
}
export function setScope(scope) {
  state.scope = scope;
  bus.emit(T.filter);
}

export function setCatalog({ models, agents }) {
  if (models) state.models = models;
  if (agents) state.agents = agents;
  bus.emit(T.catalog);
}

export function setDraft(draft) {
  state.draft = draft;
  bus.emit(T.draft, draft);
}
export function patchDraft(patch) {
  if (!state.draft) return null;
  Object.assign(state.draft, patch);
  bus.emit(T.draft, state.draft);
  return state.draft;
}

export function setAttachments(list) {
  state.attachments = list;
  bus.emit(T.attachments);
}
export function addAttachment(a) {
  state.attachments.push(a);
  bus.emit(T.attachments);
}
export function removeAttachment(i) {
  state.attachments.splice(i, 1);
  bus.emit(T.attachments);
}
export function attachmentsChanged() {
  bus.emit(T.attachments);
}

export default state;
