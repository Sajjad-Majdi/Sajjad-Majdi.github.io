/* opencode gui — composition root.

   Architecture, in one breath: a single store holds the state, an event bus
   carries every change, services do the talking to the server, and each
   component in ui/ subscribes to the topics it draws from. Nothing reaches
   across into another component's DOM, and no module imports the one that
   imports it. */

import { gui, v2 } from "./core/api.js";
import { icons, sleep } from "./core/dom.js";
import state, { setInfo } from "./core/store.js";
import { loadAgents, loadModels } from "./services/catalog.js";
import { auditDirs } from "./services/dirs.js";
import { loadActive, loadSessions } from "./services/sessions.js";
import { connect } from "./services/stream.js";
import { reconcile } from "./ui/actions.js";
import { mountAttachments } from "./ui/attachments.js";
import { mountComposer } from "./ui/composer.js";
import { startDraft } from "./ui/draft.js";
import { mountFolderPicker } from "./ui/folderpicker.js";
import { mountHeader } from "./ui/header.js";
import { mountLightbox } from "./ui/lightbox.js";
import { mountApprovals } from "./ui/log/approvals.js";
import { mountMessageActions } from "./ui/log/edit.js";
import { mountConversation } from "./ui/log/view.js";
import { mountPickers } from "./ui/pickers.js";
import { mountPopover } from "./ui/popover.js";
import { mountShortcuts } from "./ui/shortcuts.js";
import { mountSidebar } from "./ui/sidebar.js";
import { mountTheme } from "./ui/theme.js";
import { toast } from "./ui/toast.js";

function mountAll() {
  mountPopover();
  mountSidebar();
  mountHeader();
  mountPickers();
  mountFolderPicker();
  mountAttachments();
  mountComposer();
  mountConversation();
  mountMessageActions();
  mountApprovals();
  mountLightbox();
  mountShortcuts();
}

async function boot() {
  mountTheme();                              // paint in the right colours first
  try { setInfo(await gui("/info")); } catch {}

  /* the opencode server may still be starting up behind us */
  for (let i = 0; i < 24; i++) {
    try { await v2("/health"); break; } catch { await sleep(400); }
  }

  await Promise.all([loadModels(), loadAgents()]);
  await Promise.all([
    loadSessions().catch((e) => toast("Cannot list sessions — " + e.message, true)),
    loadActive(),
  ]);

  mountAll();
  connect();

  /* A folder can disappear between visits, and opencode fails every prompt in
     one that is gone. Find out once, up front, and mark those sessions. */
  auditDirs([...state.sessions.values()].map((s) => s.location?.directory || s.directory));

  startDraft();
  icons();

  /* events can be missed; the server stays the authority */
  setInterval(reconcile, 5000);
}

boot();
