/* Models and agents: what the server offers, and what is safe to offer back. */

import { v1, v2 } from "../core/api.js";
import { modelKey } from "../core/format.js";
import state, { setCatalog, lastActivity } from "../core/store.js";
import { badVariants } from "./prefs.js";

/* The v2 catalog does not carry thinking levels; the provider config does — it
   lists each model's variants (low / medium / high reasoning effort). Read that,
   and fall back to the v2 list if it is unavailable. */
export async function loadModels() {
  try {
    const cfg = await v1("/config/providers");
    const out = [];
    for (const p of cfg.providers || []) {
      for (const [id, m] of Object.entries(p.models || {})) {
        if (m.status && m.status !== "active") continue;
        out.push({
          id,
          providerID: p.id,
          name: m.name || id,
          variants: Object.keys(m.variants || {}),
          reasoning: !!m.capabilities?.reasoning,
        });
      }
    }
    if (out.length) return setCatalog({ models: out });
  } catch {}
  try {
    const r = await v2("/model");
    const models = (r.data || [])
      .filter((m) => m.enabled !== false)
      .map((m) => ({ id: m.id, providerID: m.providerID, name: m.name || m.id, variants: [], reasoning: false }));
    setCatalog({ models });
  } catch { setCatalog({ models: [] }); }
}

export async function loadAgents() {
  try {
    const all = (await v2("/agent")).data || [];
    const visible = all.filter((a) => !a.hidden && a.mode !== "subagent");
    setCatalog({ agents: visible.length ? visible : all });
  } catch { setCatalog({ agents: [] }); }
}

export function findModel(key) {
  if (!key) return null;
  const i = key.indexOf("/");
  const pid = key.slice(0, i), id = key.slice(i + 1);
  return state.models.find((m) => m.providerID === pid && m.id === id) || null;
}

/* /config/providers lists levels the runner can still refuse at runtime
   (VariantUnavailableError, with no event at all). A refused level is hidden
   for that model from then on, so the picker only ever shows levels that run. */
export function variantsOf(m) {
  if (!m || !m.variants) return [];
  const v = m.variants;
  const names = Array.isArray(v) ? v.map((x) => (typeof x === "string" ? x : x.id || x.name)) : Object.keys(v);
  const bad = new Set(badVariants()[modelKey(m)] || []);
  return names.filter(Boolean).filter((x) => x !== "default" && !bad.has(x));
}

/* picker rows, grouped by provider */
export function modelOptions(q) {
  const term = (q || "").toLowerCase().trim();
  const words = term ? term.split(/\s+/) : [];
  const groups = new Map();
  for (const m of state.models) {
    const hay = ((m.name || "") + " " + m.id + " " + m.providerID).toLowerCase();
    if (words.length && !words.every((w) => hay.includes(w))) continue;
    if (!groups.has(m.providerID)) groups.set(m.providerID, []);
    groups.get(m.providerID).push({
      value: m.providerID + "/" + m.id,
      label: m.name || m.id,
      note: variantsOf(m).length ? "thinking" : "",
    });
  }
  return [...groups.entries()]
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([g, items]) => ({ group: g, items: items.sort((a, b) => a.label.localeCompare(b.label)) }));
}

export const levelOptions = (vs) => [{
  group: "",
  items: ["default", ...vs].map((v) => ({ value: v, label: v, note: "" })),
}];

/* the folders of the most recently active sessions */
export function recentDirs(limit = 6) {
  const seen = [];
  const byRecent = [...state.sessions.values()].sort((a, b) => lastActivity(b) - lastActivity(a));
  for (const x of byRecent) {
    const d = x.location?.directory || x.directory;
    if (d && !seen.includes(d)) seen.push(d);
    if (seen.length >= limit) break;
  }
  return seen;
}
