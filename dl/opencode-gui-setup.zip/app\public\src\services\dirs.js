/* Folder lookups on the machine the server runs on.

   opencode fails every prompt in a directory that is not there, with an error
   that names nothing, so this is checked before a folder is used — and the
   answers are remembered, because the same handful of folders is asked about
   over and over. */

import { gui, json } from "../core/api.js";
import { markDir } from "../core/store.js";

const known = new Map();   // path -> true | false

export const listDir = (path) =>
  gui("/dirs?path=" + encodeURIComponent(path)).then((r) => r.data).catch(() => null);

export const resolveDirName = (name, hints) =>
  gui("/resolve-dir", json({ name, hints })).then((r) => r.data?.matches || []);

/* The server answers 400 for a folder that is not there, so a null is a no. */
export async function dirExists(path, { fresh = false } = {}) {
  if (!path) return false;
  if (!fresh && known.has(path)) return known.get(path);
  const ok = Boolean(await listDir(path));
  known.set(path, ok);
  markDir(path, ok);
  return ok;
}

/* What we already know, without asking again: true, false, or undefined. */
export const dirKnown = (path) => known.get(path);

/* Check a set of folders once, in parallel. */
export async function auditDirs(paths, opts) {
  const list = [...new Set(paths.filter(Boolean))];
  await Promise.all(list.map((p) => dirExists(p, opts)));
  return list.filter((p) => known.get(p) === false);
}

/* Only the folders that are really there. */
export const existingDirs = (paths) => paths.filter((p) => known.get(p) !== false);
