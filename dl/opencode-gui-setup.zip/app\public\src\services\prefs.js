/* Everything this app keeps in the browser between visits.

   One module owns localStorage, so a key is spelled in exactly one place and a
   broken or missing value never reaches the rest of the code. */

const read = (key, fallback) => {
  try {
    const raw = localStorage.getItem(key);
    return raw == null ? fallback : JSON.parse(raw);
  } catch { return fallback; }
};
const write = (key, value) => {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
};

/* theme + sidebar are plain strings, kept as they were written */
export const theme = {
  get: () => localStorage.getItem("oc-theme") || "dark",
  set: (t) => { try { localStorage.setItem("oc-theme", t); } catch {} },
};
export const nav = {
  hidden: () => localStorage.getItem("oc-nav") === "hidden",
  set: (hidden) => { try { localStorage.setItem("oc-nav", hidden ? "hidden" : "shown"); } catch {} },
};

/* the last folder, model, thinking level and agent — the way the terminal keeps them */
export const remembered = () => read("oc-last", {}) || {};
export const remember = (patch) => write("oc-last", { ...remembered(), ...patch });

/* Thinking levels the server has refused, per model ("provider/id" -> ["high"]). */
export const badVariants = () => read("oc-bad-variants", {}) || {};
export function markVariantBad(key, variant) {
  if (!key || !variant || variant === "default") return;
  const all = badVariants();
  const list = all[key] || [];
  if (!list.includes(variant)) list.push(variant);
  all[key] = list;
  write("oc-bad-variants", all);
}
