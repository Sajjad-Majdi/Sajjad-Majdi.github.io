/* Every call this app makes about a session lives here.

   These functions fetch and send; they do not draw. The store is updated where
   the answer is the truth (the session record, who is working), and the views
   redraw from that. */

import { v1, v2, post } from "../core/api.js";
import state, { putSession, setSessions, dropSession, replaceStatus } from "../core/store.js";

export async function loadSessions() {
  const r = await v2("/session?limit=100&order=desc");
  setSessions(r.data || []);
}

export async function fetchSession(id) {
  const s = (await v2("/session/" + id)).data;
  if (s) putSession(s);
  return s;
}

/* Reconcile who is working against the server. Returns true if it changed. */
export async function loadActive() {
  let next;
  try {
    const d = (await v2("/session/active")).data || {};
    const rows = Array.isArray(d) ? d : Object.entries(d);
    next = new Map();
    for (const row of rows) {
      if (Array.isArray(row)) next.set(row[0], row[1]?.type || row[1]?.status?.type || "busy");
      else if (row?.sessionID) next.set(row.sessionID, row.status?.type || "busy");
    }
  } catch { return false; }
  return replaceStatus(next);
}

/* Newer sessions keep a durable event log; replaying it through the same
   renderer the live stream uses means history and live look identical. */
export async function fetchHistory(id, limit = 100, pages = 40) {
  let events = [];
  let after = null;
  for (let page = 0; page < pages; page++) {
    const q = "/session/" + id + "/history?limit=" + limit +
      (after ? "&after=" + encodeURIComponent(after) : "");
    const batch = (await v2(q)).data || [];
    if (!batch.length) break;
    events = events.concat(batch);
    after = batch[batch.length - 1]?.durable?.seq;
    if (batch.length < limit || after == null) break;
  }
  return events;
}

/* Sessions written by older opencode builds only have the message store. */
export function fetchMessages(id) {
  const dir = state.sessions.get(id)?.location?.directory || "";
  return v1("/session/" + id + "/message?limit=200" + (dir ? "&directory=" + encodeURIComponent(dir) : ""));
}

export async function createSession(body) {
  const s = (await post("/session", body)).data;
  putSession(s);
  return s;
}

/* Delete lives on the v1 store. The v2 path answers the SPA page with 200,
   which looks like success but deletes nothing — so go v1 with directory. */
export async function removeSession(id) {
  const s = state.sessions.get(id);
  const dir = s?.location?.directory || s?.directory || "";
  await v1("/session/" + id + (dir ? "?directory=" + encodeURIComponent(dir) : ""), { method: "DELETE" });
  dropSession(id);
}

/* Rename lives on the v1 store, for the same reason delete does: the v2 path
   answers the SPA page with 200, which looks like success and renames nothing. */
export function renameSession(id, title) {
  const s = state.sessions.get(id);
  const dir = s?.location?.directory || s?.directory || "";
  return v1("/session/" + id + (dir ? "?directory=" + encodeURIComponent(dir) : ""), {
    method: "PATCH",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ title }),
  });
}

export const sendPrompt = (id, payload) => post("/session/" + id + "/prompt", payload);
export const interruptSession = (id) => post("/session/" + id + "/interrupt", {});
export const setSessionAgent = (id, agent) => post("/session/" + id + "/agent", { agent });
export const setSessionModelApi = (id, model) => post("/session/" + id + "/model", { model });
export const stageRevert = (id, messageID) => post("/session/" + id + "/revert/stage", { messageID });
export const commitRevert = (id) => post("/session/" + id + "/revert/commit", {});

export const listPermissions = (id) => v2("/session/" + id + "/permission").then((r) => r.data || []);
export const listQuestions = (id) => v2("/session/" + id + "/question").then((r) => r.data || []);
export const replyPermissionApi = (id, requestID, reply) =>
  post("/session/" + id + "/permission/" + requestID + "/reply", { reply });
export const replyQuestionApi = (id, requestID, answers) =>
  post("/session/" + id + "/question/" + requestID + "/reply", { answers });
