/* The live event stream.

   One EventSource, one translation: server events become store changes plus a
   named signal on the bus. Views listen for the signal they care about; nothing
   here knows what the screen looks like. */

import bus from "../core/bus.js";
import state, {
  T, touch, putSession, dropSession, setStatus, setActivity, bumpAsking, isCurrent,
} from "../core/store.js";

/* signals this service raises */
export const E = {
  live: "stream:live",                 // an event for the open session
  idle: "stream:idle",                 // that session stopped working
  gone: "stream:session-gone",         // the open session was deleted
  reverted: "stream:reverted",         // history was rewound elsewhere
  permissionAsked: "stream:permission-asked",
  permissionReplied: "stream:permission-replied",
  questionAsked: "stream:question-asked",
  questionReplied: "stream:question-replied",
};

/* Events that only mean "still working", with the word for the status line. */
const BUSY_MARK = {
  "session.next.prompted": "",
  "session.next.step.started": "starting",
  "session.next.text.started": "writing",
  "session.next.reasoning.started": "thinking",
};

let es = null;

export function connect() {
  if (es) es.close();
  es = new EventSource("/oc/api/event");
  es.onerror = () => {
    setTimeout(() => { if (!es || es.readyState === 2) connect(); }, 2500);
  };
  es.onmessage = (m) => {
    let ev;
    try { ev = JSON.parse(m.data); } catch { return; }
    handle(ev);
  };
}

export function handle(ev) {
  const t = ev.type;
  const d = ev.data || {};
  const sid = d.sessionID || d.info?.id;
  if (sid) touch(sid);
  let dirty = true;

  if (t === "session.created" || t === "session.updated") {
    if (d.info) putSession(d.info);
  } else if (t === "session.deleted") {
    const wasOpen = isCurrent(sid);
    dropSession(sid);
    if (wasOpen) bus.emit(E.gone, sid);
  } else if (t === "session.status") {
    const type = d.status?.type || "idle";
    setStatus(sid, type);
    if (type === "idle" && isCurrent(sid)) bus.emit(E.idle, sid);
  } else if (t === "session.idle") {
    setStatus(sid, "idle");
    if (isCurrent(sid)) bus.emit(E.idle, sid);
  } else if (t === "permission.v2.asked" || t === "permission.asked") {
    bumpAsking(sid, 1);
    if (isCurrent(sid)) bus.emit(E.permissionAsked, d);
  } else if (t === "permission.v2.replied" || t === "permission.replied") {
    bumpAsking(sid, -1);
    if (isCurrent(sid)) bus.emit(E.permissionReplied, { id: d.requestID || d.id, reply: d.reply });
  } else if (t === "question.v2.asked" || t === "question.asked") {
    bumpAsking(sid, 1);
    if (isCurrent(sid)) bus.emit(E.questionAsked, d);
  } else if (t === "question.v2.replied" || t === "question.v2.rejected" ||
             t === "question.replied" || t === "question.rejected") {
    bumpAsking(sid, -1);
    if (isCurrent(sid)) bus.emit(E.questionReplied, { id: d.requestID || d.id });
  } else if (t === "session.next.revert.committed") {
    /* Rewound elsewhere (or by us) — the view redraws without the cut messages.
       Our own commit is skipped: the edit flow reloads right after it. */
    if (isCurrent(sid) && Date.now() - (state.revertTs || 0) > 5000) bus.emit(E.reverted, sid);
  } else if (t === "session.next.tool.called") {
    setStatus(sid, "busy", d.tool);
  } else if (t in BUSY_MARK) {
    setStatus(sid, "busy");
    if (BUSY_MARK[t]) setActivity(sid, BUSY_MARK[t]);
  } else {
    dirty = false;
  }

  /* the list carries relative times and live labels — nudge it either way */
  if (dirty) bus.emit(T.sessions, sid);
  if (sid && isCurrent(sid)) bus.emit(E.live, ev);
}
