/* Attachments: bytes in, data: URLs out.

   Files go inline as data: URLs. The backend does not materialize file://
   attachments for the model (valid-base64 error) — inline bytes just work. */

import { gui } from "../core/api.js";

export function blobToDataURL(blob) {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(String(fr.result));
    fr.onerror = () => reject(new Error("could not read file"));
    fr.readAsDataURL(blob);
  });
}

export function uploadToServer(files) {
  const fd = new FormData();
  for (const f of files) fd.append("files", f, f.name);
  return gui("/upload", { method: "POST", body: fd }).then((r) => r.data || []);
}

export async function attachmentPayloads(files) {
  const out = [];
  for (const f of files) {
    if (f.size > 19 * 1024 * 1024) throw new Error(`“${f.name}” is too large to send`);
    if (!f.dataUrl) {
      const src = f.local || f.preview;
      if (!src) throw new Error(`“${f.name}” is not ready yet`);
      const blob = await (await fetch(src)).blob();
      f.dataUrl = await blobToDataURL(blob);
      if (!f.mime && blob.type) f.mime = blob.type;
    }
    out.push({ uri: f.dataUrl, name: f.name, ...(f.mime ? { mime: f.mime } : {}) });
  }
  return out;
}
