/* Actions a person takes on a session, wherever they take them from. */

import { titleOf } from "../core/format.js";
import state, { clearStatus, isWorking, patchSession } from "../core/store.js";
import {
  interruptSession, loadActive, removeSession, renameSession,
} from "../services/sessions.js";
import { startDraft } from "./draft.js";
import { settleOpenTurn } from "./log/view.js";
import { toast } from "./toast.js";

export async function deleteSession(id) {
  const s = state.sessions.get(id);
  if (!s || !confirm(`Delete “${titleOf(s)}”? This cannot be undone.`)) return;
  const wasOpen = state.cur === id;
  try {
    await removeSession(id);
    if (wasOpen) startDraft();
  } catch (e) { toast("Could not delete — " + e.message, true); }
}

export async function renameCurrent() {
  const s = state.sessions.get(state.cur);
  if (!s) return;
  const v = prompt("Session title", titleOf(s) === "Untitled session" ? "" : s.title || "");
  if (v == null) return;
  try {
    await renameSession(s.id, v);
    patchSession(s.id, { title: v });
  } catch (e) { toast(e.message, true); }
}

export async function interrupt() {
  const id = state.cur;
  if (!id) return;
  try {
    await interruptSession(id);
    if (id === state.cur) settleOpenTurn("stopped");
    setTimeout(reconcile, 400);
    setTimeout(reconcile, 1500);
  } catch (e) { toast("Could not stop — " + e.message, true); }
}

/* Ask the server who is really working, and tidy up if we were left behind.

   Two ways to be left behind: the status changed under us, or the stream
   dropped the end of a run and a turn is still spinning against an idle
   session. Both end the turn — nothing else ever will. */
export async function reconcile() {
  const changed = await loadActive();
  if (!state.cur || isWorking(state.cur)) return;
  const t = state.turn;
  const stranded = t && !t.done && Date.now() - (t.tLast || t.t0) > 15000;
  if (changed || stranded) settleOpenTurn();
}

export { clearStatus };
