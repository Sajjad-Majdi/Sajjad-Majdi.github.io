/* The strip of files waiting to be sent with the next message. */

import bus from "../core/bus.js";
import { $, coalesce, esc } from "../core/dom.js";
import { fmtBytes, isImage } from "../core/format.js";
import state, { T, addAttachment, attachmentsChanged, removeAttachment } from "../core/store.js";
import { uploadToServer } from "../services/uploads.js";
import { toast } from "./toast.js";

function paint() {
  const strip = $("attach-strip");
  strip.hidden = !state.attachments.length;
  strip.innerHTML = state.attachments.map((a, i) =>
    isImage(a.name)
      ? `<div class="att${a.uploading ? " up" : ""}"><img src="${esc(a.local || a.preview)}" alt="${esc(a.name)}"><button type="button" class="x" data-i="${i}" title="Remove">×</button></div>`
      : `<div class="att${a.uploading ? " up" : ""}"><div class="doc"><b>${esc(a.name)}</b><span>${fmtBytes(a.size || 0)}</span></div><button type="button" class="x" data-i="${i}" title="Remove">×</button></div>`
  ).join("");
  strip.querySelectorAll(".x").forEach((b) => {
    b.onclick = () => removeAttachment(Number(b.dataset.i));
  });
}

export const renderAttachments = coalesce(paint);

export async function uploadFiles(files) {
  if (!files.length) return;
  /* the row appears at once and fills in as the upload lands */
  const holders = files.map((f) => {
    const a = { name: f.name, size: f.size, mime: f.type || "", uploading: true, local: URL.createObjectURL(f) };
    addAttachment(a);
    return a;
  });
  try {
    const saved = await uploadToServer(files);
    saved.forEach((row, i) => {
      if (holders[i]) Object.assign(holders[i], row, { uploading: false, local: holders[i].local });
    });
  } catch (e) {
    for (const h of holders) state.attachments.splice(state.attachments.indexOf(h), 1);
    toast("Upload failed — " + e.message, true);
  }
  attachmentsChanged();
}

export function mountAttachments() {
  bus.on(T.attachments, renderAttachments);
  $("btn-attach").onclick = () => $("file-input").click();
  $("file-input").onchange = (e) => { uploadFiles([...e.target.files]); e.target.value = ""; };
}
