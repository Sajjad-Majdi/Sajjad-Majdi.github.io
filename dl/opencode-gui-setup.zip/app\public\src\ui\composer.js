/* The message box: what you type, what you attach, and the one button that
   sends it — or stops the agent, because that is where your hand already is. */

import bus from "../core/bus.js";
import { $ } from "../core/dom.js";
import state, { T, clearStatus, currentSession, isWorking, setAttachments, setStatus } from "../core/store.js";
import { dirExists } from "../services/dirs.js";
import { sendPrompt } from "../services/sessions.js";
import { attachmentPayloads } from "../services/uploads.js";
import { interrupt } from "./actions.js";
import { uploadFiles } from "./attachments.js";
import { createFromDraft } from "./draft.js";
import { scrollToEnd } from "./log/dom.js";
import { requestSessionName } from "./titles.js";
import { toast } from "./toast.js";
import { watchPrompt } from "./watchdog.js";

export function syncSendButton() {
  const working = !!state.cur && isWorking(state.cur);
  const btn = $("btn-send");
  btn.classList.toggle("stop", working);
  btn.title = working ? "Stop the agent  (Esc)" : "Send  (Enter)";
  btn.setAttribute("aria-label", working ? "Stop the agent" : "Send");
  btn.disabled = false;
}

export async function send() {
  if (!state.cur && !state.draft) return;
  const ta = $("prompt");
  const text = ta.value.trim();
  const files = state.attachments.filter((a) => a.uri);
  if (!text && !files.length) return;
  if (state.attachments.some((a) => a.uploading)) return toast("Still uploading…");
  if (state.draft && !state.draft.model) return toast("Choose a model first", true);

  const dir = state.draft ? state.draft.dir : currentSession()?.location?.directory;
  if (dir && !(await dirExists(dir, { fresh: true }))) {
    return toast("“" + dir + "” no longer exists — pick another folder.", true);
  }

  $("btn-send").disabled = true;
  const payload = { prompt: { text: text || "Please look at the attached file(s)." } };
  let id = null;
  try {
    if (files.length) payload.prompt.files = await attachmentPayloads(files);
    id = state.draft ? await createFromDraft() : state.cur;
    /* Optimistic working state: the server can take seconds before the first
       event arrives. Without this the composer looks idle after send. */
    setStatus(id, "busy", "starting");
    await sendPrompt(id, payload);
    ta.value = "";
    ta.style.height = "auto";
    setAttachments([]);
    scrollToEnd(true);
    requestSessionName(id, text);
    watchPrompt(id);
  } catch (e) {
    if (id) clearStatus(id);
    toast("Could not send — " + (await explain(e, id)), true);
  } finally {
    syncSendButton();
    ta.focus();
  }
}

/* opencode answers "Unexpected server error" for anything it did not expect,
   and a folder that has since been deleted is the common one — it fails
   realPath before the model is ever asked. Say which it was. */
async function explain(e, id) {
  const dir = id ? state.sessions.get(id)?.location?.directory : null;
  if (dir && !(await dirExists(dir, { fresh: true }))) {
    return "this session's folder “" + dir + "” no longer exists. Start a new session in a folder that does.";
  }
  return e.message;
}

export function mountComposer() {
  const ta = $("prompt");
  const comp = $("composer");

  ta.addEventListener("input", () => {
    ta.style.height = "auto";
    ta.style.height = Math.min(ta.scrollHeight, 200) + "px";
  });
  ta.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); comp.requestSubmit(); }
    if (e.key === "Escape" && state.cur && isWorking(state.cur)) { e.preventDefault(); interrupt(); }
  });
  comp.onsubmit = (e) => {
    e.preventDefault();
    if (state.cur && isWorking(state.cur)) interrupt();
    else send();
  };

  ["dragenter", "dragover"].forEach((n) =>
    comp.addEventListener(n, (e) => { e.preventDefault(); comp.classList.add("drag"); }));
  ["dragleave", "drop"].forEach((n) =>
    comp.addEventListener(n, (e) => { e.preventDefault(); comp.classList.remove("drag"); }));
  comp.addEventListener("drop", (e) => {
    if (e.dataTransfer?.files?.length) uploadFiles([...e.dataTransfer.files]);
  });
  ta.addEventListener("paste", (e) => {
    const files = [...(e.clipboardData?.files || [])];
    if (files.length) { e.preventDefault(); uploadFiles(files); }
  });

  for (const topic of [T.status, T.current]) bus.on(topic, syncSendButton);
  syncSendButton();
}
