/* The unsent session.

   "New session" opens an empty chat, not a dialog: folder, model, thinking
   level and agent are chips in the message box, and the session is created on
   the server only when the first message is sent. */

import { $ } from "../core/dom.js";
import { modelKey } from "../core/format.js";
import state, { patchDraft, setAttachments, setCurrent, setDraft, touch } from "../core/store.js";
import { findModel, variantsOf } from "../services/catalog.js";
import { remember, remembered } from "../services/prefs.js";
import { dirExists } from "../services/dirs.js";
import { createSession } from "../services/sessions.js";
import { clearLog } from "./log/dom.js";
import { toast } from "./toast.js";

export function startDraft() {
  const cur = state.sessions.get(state.cur);
  const last = remembered();
  const draft = {
    dir: last.dir || cur?.location?.directory || state.info.cwd || "",
    model: last.model || modelKey(cur?.model) ||
      (state.models[0] ? state.models[0].providerID + "/" + state.models[0].id : null),
    variant: last.variant || "default",
    agent: last.agent || cur?.agent || (state.agents[0]?.id ?? "build"),
  };
  if (!variantsOf(findModel(draft.model)).includes(draft.variant)) draft.variant = "default";

  setCurrent(null);
  state.nodes.clear();
  setAttachments([]);
  setDraft(draft);

  $("empty").hidden = true;
  $("workspace").hidden = false;
  $("workspace").classList.add("draft");
  $("draft-intro").hidden = false;
  $("btn-bottom").hidden = true;
  clearLog();

  const ta = $("prompt");
  ta.value = "";
  ta.style.height = "auto";
  ta.focus();

  checkDraftDir(draft);
}

/* A remembered folder can be renamed or deleted between visits. opencode fails
   the whole prompt on a missing directory — with an error that says nothing —
   so drop it here, before it can be sent. */
async function checkDraftDir(draft) {
  const dir = draft.dir;
  if (!dir || (await dirExists(dir))) return;
  if (state.draft !== draft) return;
  const fallback = state.info.cwd || "";
  patchDraft({ dir: fallback });
  remember({ dir: fallback });
  toast("“" + dir + "” is gone — using " + (fallback || "the server folder") + " instead.", true);
}

export function endDraft() {
  if (state.draft) setDraft(null);
  $("workspace").classList.remove("draft");
  $("draft-intro").hidden = true;
}

/* The first send is what actually creates the session. */
export async function createFromDraft() {
  const d = state.draft;
  const i = d.model.indexOf("/");
  const model = { providerID: d.model.slice(0, i), id: d.model.slice(i + 1) };
  if (d.variant && d.variant !== "default") model.variant = d.variant;
  const body = { agent: d.agent, model };
  if (d.dir) body.location = { directory: d.dir };

  const s = await createSession(body);
  touch(s.id);
  endDraft();
  setCurrent(s.id);
  state.nodes.clear();
  state.pinned = true;
  clearLog();
  return s.id;
}
