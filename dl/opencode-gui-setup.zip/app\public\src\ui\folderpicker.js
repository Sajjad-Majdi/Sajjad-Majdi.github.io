/* Choosing the folder a new session will work in.

   The list is what you already use: this folder, the recent ones, anything a
   dropped folder name resolves to. A full path typed in the search box works
   too — the server resolves a bare name for us. */

import bus from "../core/bus.js";
import { $ } from "../core/dom.js";
import { baseName, parentName } from "../core/format.js";
import state, { patchDraft } from "../core/store.js";
import { recentDirs } from "../services/catalog.js";
import { auditDirs, dirExists, existingDirs, listDir, resolveDirName } from "../services/dirs.js";
import { remember } from "../services/prefs.js";
import { closePop, openPop, popAnchor } from "./popover.js";
import { toast } from "./toast.js";

export async function openFolderPop(anchor) {
  if (!state.draft) return;
  const here = state.draft.dir || state.info.cwd || "";
  const d = await listDir(here);
  /* a recent folder can be gone; do not offer it again */
  await auditDirs(recentDirs());

  const build = (term) => {
    const t = (term || "").trim();
    const low = t.toLowerCase();
    const groups = [];

    if (state.dirMatches?.matches?.length) {
      groups.push({
        group: "found",
        items: state.dirMatches.matches.map((x) => ({
          value: "use:" + x, label: baseName(x) || x, note: parentName(x),
        })),
      });
    }

    const head = [];
    if (t && /[\/]/.test(t)) head.push({ value: "use:" + t, label: t, note: "use" });
    const cur = d ? d.dir : here;
    if (cur) head.push({ value: "use:" + cur, label: baseName(cur) || cur, note: "use this" });
    if (head.length) groups.push({ group: "", items: head });

    const rec = existingDirs(recentDirs()).filter((x) => x !== cur && (!t || x.toLowerCase().includes(low)));
    if (rec.length) {
      const names = rec.map((x) => baseName(x) || x);
      groups.push({
        group: "recent",
        items: rec.map((x, i) => ({
          value: "use:" + x,
          label: names[i],
          /* same name twice — say which parent it lives in */
          note: names.filter((n) => n === names[i]).length > 1 ? parentName(x) : "",
        })),
      });
    }
    return groups;
  };

  openPop(anchor, {
    options: build,
    value: "use:" + (d ? d.dir : here),
    placeholder: "Drag a folder here or type its path",
    onPick: (v) => useDir(v.slice(4)),
  });

  /* Dropping a folder reveals its name with no prompt at all — the server
     resolves it to a full path below. */
  const pop = $("pop");
  pop.ondragover = (e) => e.preventDefault();
  pop.ondrop = (e) => {
    e.preventDefault();
    const name = folderFromDrop(e.dataTransfer);
    if (name) resolvePickedName(name);
  };
}

/* A path can be typed as well as picked, and a recent folder can be gone —
   opencode fails every prompt in a directory that is not there, so check. */
async function useDir(dir) {
  if (!state.draft) return;
  if (!(await dirExists(dir))) return toast("“" + dir + "” is not a folder on this machine.", true);
  if (!state.draft) return;
  state.dirMatches = null;
  remember({ dir });
  patchDraft({ dir });
}

/* Folder name from a drop. Plain file drops carry no path, only folders do. */
export function folderFromDrop(dt) {
  if (!dt?.items) return null;
  for (const it of dt.items) {
    if (it.kind !== "file") continue;
    try {
      const entry = typeof it.webkitGetAsEntry === "function" ? it.webkitGetAsEntry() : null;
      if (entry?.isDirectory && entry.name) return entry.name;
    } catch {}
  }
  return null;
}

export async function resolvePickedName(name) {
  if (!state.draft) return;
  toast("Finding “" + name + "”…");
  let matches = [];
  try {
    matches = await resolveDirName(name, recentDirs());
  } catch (e) {
    toast("Could not find that folder — " + e.message, true);
    return;
  }

  if (matches.length === 1) {
    closePop();
    useDir(matches[0]);
  } else if (!matches.length) {
    toast("No folder named “" + name + "” under your usual places — type its path.", true);
  } else {
    const anchor = popAnchor();
    closePop();
    state.dirMatches = { name, matches };
    if (anchor) openFolderPop(anchor);
    else toast(matches.length + " folders named “" + name + "” — pick one.", false);
  }
}

export function mountFolderPicker() {
  /* a folder dropped on the chip itself, rather than on the open list */
  bus.on("folder:dropped", (dt) => {
    const name = folderFromDrop(dt);
    if (name) resolvePickedName(name);
    else toast("Drop a folder, not files.", true);
  });
}
