/* The bar above the log: what this session is called, where it runs, what it
   is doing, and what it has cost. */

import bus from "../core/bus.js";
import { $, coalesce } from "../core/dom.js";
import { titleOf } from "../core/format.js";
import state, { T, currentSession, isDirGone } from "../core/store.js";
import { deleteSession, renameCurrent } from "./actions.js";

function paint() {
  const s = currentSession();
  if (!s) return;
  /* No status up here. The work says what it is doing, in the log, as it
     happens — saying it twice only makes the header flicker. */
  const gone = isDirGone(s);
  $("s-title").textContent = titleOf(s);

  const dir = s.location?.directory || s.directory || "";
  $("s-dir").textContent = dir;
  $("s-dir").title = gone ? dir + " — this folder no longer exists" : dir;
  $("s-dir").classList.toggle("gone", gone);

  const tk = s.tokens || {};
  const total = (tk.input || 0) + (tk.output || 0) + (tk.reasoning || 0);
  $("s-usage").textContent = total
    ? total.toLocaleString() + " tokens" + (s.cost ? " · $" + s.cost.toFixed(4) : "")
    : "";
}

export const renderHeader = coalesce(paint);

export function mountHeader() {
  $("btn-del").onclick = () => deleteSession(state.cur);
  $("btn-rename").onclick = renameCurrent;
  $("s-title").ondblclick = renameCurrent;
  for (const topic of [T.sessions, T.status, T.asking, T.current]) bus.on(topic, renderHeader);
}
