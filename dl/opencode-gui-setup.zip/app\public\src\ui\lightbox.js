/* Click an image in the log, see it whole. */

import { $ } from "../core/dom.js";

export const isLightboxOpen = () => !$("lightbox").hidden;

export function closeLightbox() {
  const box = $("lightbox");
  box.hidden = true;
  box.innerHTML = "";
}

export function openLightbox(img) {
  const box = $("lightbox");
  box.innerHTML = "";
  const full = document.createElement("img");
  full.alt = img.alt || "Attachment preview";
  full.src = img.dataset.full || img.src;
  box.appendChild(full);
  box.hidden = false;
}

export function mountLightbox() {
  document.addEventListener("click", (e) => {
    const img = e.target.closest(".att-thumb");
    if (img) openLightbox(img);
  });
  $("lightbox").onclick = closeLightbox;
}
