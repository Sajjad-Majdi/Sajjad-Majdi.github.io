/* Approvals and questions, in the stream where the work stopped.

   opencode stops and asks before it touches anything outside the session's own
   folder. The terminal shows that prompt. Without it here the run simply hangs,
   which is indistinguishable from a crash. */

import bus from "../../core/bus.js";
import { esc, icons } from "../../core/dom.js";
import state, { setAsking } from "../../core/store.js";
import {
  listPermissions, listQuestions, replyPermissionApi, replyQuestionApi,
} from "../../services/sessions.js";
import { E } from "../../services/stream.js";
import { toast } from "../toast.js";
import { addRow, keepPinned, scrollToEnd } from "./dom.js";

function permissionText(action) {
  switch (action) {
    case "external_directory": return "The agent wants to work outside this session's folder.";
    case "edit": return "The agent wants to change files.";
    case "bash": return "The agent wants to run a shell command.";
    case "webfetch": return "The agent wants to fetch a page from the web.";
    default: return "The agent is asking for permission: " + (action || "unknown") + ".";
  }
}

function askShell(id, headIcon, headText, inner) {
  const row = addRow(
    '<section class="ask" data-ask="' + esc(id) + '">' +
      '<div class="ask-head"><i data-lucide="' + headIcon + '"></i>' + esc(headText) + '</div>' +
      inner +
    '</section>'
  );
  state.nodes.set("ask-" + id, row);
  icons();
  scrollToEnd(true);
  return row;
}

export function renderPermission(d) {
  const id = d.id;
  if (!id || state.nodes.has("ask-" + id)) return;
  const res = (d.resources || []).join("\n");
  const inner =
    '<div class="ask-what">' + esc(permissionText(d.action)) + '</div>' +
    (res ? '<div class="ask-res mono" dir="ltr">' + esc(res) + '</div>' : "") +
    '<div class="ask-actions">' +
      '<button type="button" class="ask-btn go" data-reply="once">Allow once</button>' +
      '<button type="button" class="ask-btn" data-reply="always">Always allow</button>' +
      '<button type="button" class="ask-btn no" data-reply="reject">Deny</button>' +
    '</div>';
  const row = askShell(id, "shield-question", "Permission needed", inner);
  row.querySelectorAll("[data-reply]").forEach((b) => {
    b.onclick = () => replyPermission(id, b.dataset.reply, row);
  });
}

async function replyPermission(id, reply, row) {
  const buttons = row.querySelectorAll("button");
  buttons.forEach((b) => (b.disabled = true));
  try {
    await replyPermissionApi(state.cur, id, reply);
    closeAsk(id);
  } catch (e) {
    buttons.forEach((b) => (b.disabled = false));
    toast("Could not answer - " + e.message, true);
  }
}

export function renderQuestion(d) {
  const id = d.id;
  if (!id || state.nodes.has("ask-" + id)) return;
  const qs = d.questions || [];
  const inner = qs.map((q, qi) =>
    '<div class="ask-what" dir="auto">' + esc(q.question) + '</div>' +
    '<div class="ask-actions">' +
      (q.options || []).map((o) => {
        const label = o && o.label != null ? o.label : String(o);
        return '<button type="button" class="ask-btn' + (qi === 0 ? " go" : "") +
               '" data-label="' + esc(label) + '">' + esc(label) + '</button>';
      }).join("") +
    '</div>'
  ).join("");
  const row = askShell(id, "circle-help", "The agent has a question", inner);
  row.querySelectorAll("[data-label]").forEach((b) => {
    b.onclick = async () => {
      const buttons = row.querySelectorAll("button");
      buttons.forEach((x) => (x.disabled = true));
      try {
        await replyQuestionApi(state.cur, id, [[b.dataset.label]]);
        closeAsk(id);
      } catch (e) {
        buttons.forEach((x) => (x.disabled = false));
        toast("Could not answer - " + e.message, true);
      }
    };
  });
}

/* Answered cards leave the log. The run continues below them. */
export function closeAsk(id) {
  const row = state.nodes.get("ask-" + id);
  state.nodes.delete("ask-" + id);
  if (!row) return;
  if (row.isConnected) row.remove();
  keepPinned();
}

/* anything already waiting when the session is opened */
export async function loadPending(id) {
  let n = 0;
  try {
    const perms = await listPermissions(id);
    if (id !== state.cur) return;
    n += perms.length;
    for (const p of perms) renderPermission(p);
  } catch {}
  try {
    const qs = await listQuestions(id);
    if (id !== state.cur) return;
    n += qs.length;
    for (const q of qs) renderQuestion(q);
  } catch {}
  setAsking(id, n);
}

export function mountApprovals() {
  bus.on(E.permissionAsked, renderPermission);
  bus.on(E.questionAsked, renderQuestion);
  bus.on(E.permissionReplied, ({ id }) => closeAsk(id));
  bus.on(E.questionReplied, ({ id }) => closeAsk(id));
}
