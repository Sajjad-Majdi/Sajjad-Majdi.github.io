/* The log's building blocks: rows, scrolling, and where the next thing goes.

   Everything the conversation view appends passes through here, so the rule
   about following the live end is written once. */

import { $, icons } from "../../core/dom.js";
import state from "../../core/store.js";

export const logEl = () => $("log");

export function clearLog() {
  logEl().innerHTML = "";
  state.nodes.clear();
}

export function addRow(html, cls = "") {
  if (cls !== "empty-note") logEl().querySelector(".row.empty-note")?.remove();
  const el = document.createElement("div");
  el.className = "row" + (cls ? " " + cls : "");
  el.innerHTML = html;
  logEl().appendChild(el);
  icons();
  keepPinned();
  return el;
}

let pinTick = 0;
export function keepPinned() {
  if (!state.pinned || pinTick) return;
  pinTick = requestAnimationFrame(() => {
    pinTick = 0;
    const l = logEl();
    l.scrollTop = l.scrollHeight;
  });
}

export function scrollToEnd(force) {
  if (force) { state.pinned = true; $("btn-bottom").hidden = true; }
  const l = logEl();
  l.scrollTop = l.scrollHeight;
}

function assistantShell() {
  const row = document.createElement("div");
  row.className = "row";
  row.innerHTML = `<div class="msg"><div class="msg-body"></div></div>`;
  logEl().appendChild(row);
  icons();
  keepPinned();
  return row.querySelector(".msg-body");
}

/* Where the next block belongs: inside the open turn, or in a message of its own. */
export function currentBody() {
  if (state.turn && !state.turn.done) return state.turn.body;
  let body = state.nodes.get("body");
  if (!body || !body.isConnected) {
    body = assistantShell();
    state.nodes.set("body", body);
  }
  return body;
}

/* An entry that is still spinning when the turn ends never got its result —
   the run was interrupted or the tool never answered. Say so, rather than
   animating forever. */
export function settleRunning(reason) {
  for (const el of logEl().querySelectorAll('.entry[data-state="run"]')) {
    el.dataset.state = "held";
    const detail = el.querySelector(".edetail");
    if (detail && !detail.dataset.held) {
      detail.dataset.held = "1";
      detail.textContent = reason || "no result";
    }
  }
}
