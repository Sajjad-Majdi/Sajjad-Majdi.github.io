/* Editing a message you already sent.

   The bubble turns into a field with Update / Cancel. Update rewinds opencode
   to that message (stage + commit, like the terminal's undo) and sends the
   edited text with the same files. */

import { icons } from "../../core/dom.js";
import { localSrc } from "../../core/format.js";
import state, { isWorking } from "../../core/store.js";
import { commitRevert, sendPrompt, stageRevert } from "../../services/sessions.js";
import { blobToDataURL } from "../../services/uploads.js";
import { toast } from "../toast.js";
import { logEl, scrollToEnd } from "./dom.js";
import { openSession } from "./view.js";

export async function copyText(t) {
  try { await navigator.clipboard.writeText(t); toast("Copied"); }
  catch {
    const ta = document.createElement("textarea");
    ta.value = t;
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand("copy"); toast("Copied"); }
    catch { toast("Copy failed", true); }
    ta.remove();
  }
}

export function startEdit(row) {
  if (!state.cur || !row) return;
  if (state.editing) cancelEdit();
  const msg = row._msg;
  if (!msg?.id) return toast("No message id — reopen the session and try again", true);
  if (isWorking(state.cur)) return toast("Stop the agent first");
  const bubble = row.querySelector(".bubble");
  if (!bubble) return;

  row.classList.add("editing");
  row._editHTML = bubble.innerHTML;
  /* The bubble is sized by its text, and three words make a bubble too narrow
     to edit in. Editing gives it a width of its own — see .row.user.editing. */
  bubble.innerHTML =
    `<textarea class="edit-field" dir="auto" rows="3"></textarea>` +
    `<div class="edit-actions">` +
      `<button type="button" class="btn-ghost sm" data-edit="cancel">Cancel</button>` +
      `<button type="button" class="btn-primary" data-edit="update">Update</button>` +
    `</div>`;

  const field = bubble.querySelector(".edit-field");
  field.value = msg.text || "";
  const fit = () => { field.style.height = "auto"; field.style.height = Math.min(field.scrollHeight, 300) + "px"; };
  field.addEventListener("input", fit);
  fit();
  field.focus();
  bubble.querySelector('[data-edit="cancel"]').onclick = () => cancelEdit();
  bubble.querySelector('[data-edit="update"]').onclick = () => commitEdit(row);
  state.editing = row;
}

export function cancelEdit() {
  const row = state.editing;
  state.editing = null;
  if (!row || !row.isConnected) return;
  const bubble = row.querySelector(".bubble");
  if (bubble && row._editHTML !== undefined) {
    bubble.innerHTML = row._editHTML;
    icons();
  }
  row.classList.remove("editing");
  row._editHTML = undefined;
}

/* Files survive a rewind: data: URLs resend as-is, anything else is read
   back to bytes first (the backend only accepts inline media). */
async function editFilesToPayload(files) {
  const out = [];
  for (const f of files || []) {
    if (!f.uri) continue;
    if (f.uri.startsWith("data:")) {
      out.push({ uri: f.uri, name: f.name, ...(f.mime ? { mime: f.mime } : {}) });
      continue;
    }
    const src = /^file:\/\//i.test(f.uri) ? localSrc(f.uri) : f.uri;
    const blob = await (await fetch(src)).blob();
    out.push({ uri: await blobToDataURL(blob), name: f.name, ...((blob.type || f.mime) ? { mime: blob.type || f.mime } : {}) });
  }
  return out;
}

async function commitEdit(row) {
  const msg = row._msg;
  const bubble = row.querySelector(".bubble");
  const field = bubble?.querySelector(".edit-field");
  const text = field ? field.value.trim() : "";
  if (!msg?.id || !state.cur) return;
  if (!text) return toast("Message is empty");

  const id = state.cur;
  bubble.querySelectorAll("button").forEach((b) => (b.disabled = true));
  try {
    state.revertTs = Date.now();
    await stageRevert(id, msg.id);
    await commitRevert(id);
    const files = await editFilesToPayload(msg.files);
    state.editing = null;
    await openSession(id);
    if (state.cur !== id) return;
    const payload = { prompt: { text } };
    if (files.length) payload.prompt.files = files;
    await sendPrompt(id, payload);
    scrollToEnd(true);
  } catch (e) {
    cancelEdit();
    toast("Could not update — " + e.message, true);
  }
}

/* copy / rewind buttons on a user bubble */
export function mountMessageActions() {
  logEl().addEventListener("click", (e) => {
    const btn = e.target.closest("[data-act]");
    if (!btn) return;
    const msg = btn.closest(".row")?._msg;
    if (!msg) return;
    if (btn.dataset.act === "copy" && msg.text) copyText(msg.text);
    else if (btn.dataset.act === "rewind") startEdit(btn.closest(".row"));
  });
}
