/* The two kinds of thing a turn contains: streamed text, and marginal entries. */

import { esc } from "../../core/dom.js";
import { clip } from "../../core/format.js";
import state from "../../core/store.js";
import { currentBody, keepPinned } from "./dom.js";

/* A streaming text block. It is plain text while it arrives and becomes
   formatted once the model stops writing. */
export function textPart(key) {
  let n = state.nodes.get(key);
  if (n && n.el.isConnected) return n;
  const el = document.createElement("div");
  el.className = "assistant";
  el.dir = "auto";
  currentBody().appendChild(el);
  if (state.turn && !state.turn.done) state.turn.texts.push(el);
  n = { el, buf: "" };
  state.nodes.set(key, n);
  keepPinned();
  return n;
}

/* A marginal entry: it hangs off the gutter rule that runs down the turn, so a
   run of tool calls reads as one ruled column instead of a stack of boxes. The
   state lives in the mark on the rule, not in a colour. */
export function entryPart(key, { name, detail, think, t0 }) {
  let n = state.nodes.get(key);
  if (n && n.el.isConnected) return n;

  const el = document.createElement("div");
  el.className = "entry" + (think ? " think" : "");
  el.dataset.state = "run";
  el.innerHTML = `<span class="gutter"><span class="node"></span></span>
<div class="entry-main">
  <button type="button" class="entry-head">
    <span class="ename"></span>
    <span class="edetail" dir="auto"></span>
    <span class="edur"></span>
    <svg class="echev lucide" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>
  </button>
  <div class="entry-body" hidden></div>
</div>`;

  const head = el.querySelector(".entry-head");
  const body = el.querySelector(".entry-body");

  n = {
    el, body,
    name: el.querySelector(".ename"),
    detail: el.querySelector(".edetail"),
    dur: el.querySelector(".edur"),
    t0: t0 || Date.now(),
    touched: false,          // the reader has taken control of the disclosure
    set open(v) {
      body.hidden = !v;
      el.querySelector(".echev")?.classList.toggle("open", v);
    },
    get open() { return !body.hidden; },
    state(v) { el.dataset.state = v; },
    /* Nothing to reveal? Then there is no disclosure. An empty drawer that
       opens onto nothing is worse than no drawer — several providers return
       their reasoning encrypted, so this is the normal case, not an edge one. */
    disclosable(has) {
      el.classList.toggle("flat", !has);
      if (!has) body.hidden = true;
    },
  };
  head.onclick = () => {
    if (el.classList.contains("flat")) return;
    n.touched = true;
    n.open = !n.open;
  };

  n.name.textContent = name;
  if (detail) n.detail.textContent = detail;
  currentBody().appendChild(el);
  keepPinned();
  state.nodes.set(key, n);
  return n;
}

/* payload blocks inside an open entry, labelled the way the margin labels them */
export const payload = (label, text) =>
  `<div class="mlabel">${esc(label)}</div><pre class="payload" dir="auto">${esc(clip(String(text)))}</pre>`;
