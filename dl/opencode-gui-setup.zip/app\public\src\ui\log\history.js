/* Replaying a session that has no durable event log.

   Older opencode builds only kept the message store, so these messages are
   walked part by part into the same rows the live stream produces. */

import { esc } from "../../core/dom.js";
import { argOf, clip, isAbort } from "../../core/format.js";
import { finishText, mdRender } from "../../core/markdown.js";
import state from "../../core/store.js";
import { addRow, currentBody } from "./dom.js";
import { entryPart, payload } from "./entries.js";
import { countTool, endTurn, noteStep, trackText } from "./turn.js";
import { filesHtml, promptActions } from "./parts.js";

export function renderMessage(m) {
  const info = m.info || {};
  const parts = m.parts || [];

  if (info.role === "user") {
    endTurn();
    const text = parts.filter((p) => p.type === "text").map((p) => p.text).join("\n\n");
    const files = parts.filter((p) => p.type === "file").map((f) => ({ name: f.filename, uri: f.url, mime: f.mime }));
    if (!text && !files.length) return;
    const row = addRow(`<div class="bubble" dir="auto">${filesHtml(files)}${mdRender(text)}</div>${promptActions()}`, "user");
    row._msg = { id: info.id || null, text, files: files.map((f) => ({ name: f.name, uri: f.uri, mime: f.mime })) };
    state.nodes.delete("body");
    return;
  }

  for (const p of parts) {
    switch (p.type) {
      case "step-start":
        noteStep();
        break;

      case "text": {
        if (!p.text) break;
        const el = document.createElement("div");
        el.className = "assistant";
        el.dir = "auto";
        currentBody().appendChild(el);
        finishText(el, p.text);
        trackText(el);
        break;
      }

      case "reasoning": {
        if (!p.text) break;
        const secs = p.time?.start && p.time?.end ? ((p.time.end - p.time.start) / 1000).toFixed(1) : null;
        const n = entryPart("h-rsn-" + p.id, { name: secs ? `thought for ${secs}s` : "thought", think: true });
        n.state("plain");
        n.body.innerHTML = `<div class="thought" dir="auto"></div>`;
        finishText(n.body.firstChild, clip(p.text));
        n.disclosable(!!p.text.trim());
        break;
      }

      case "tool": {
        const st = p.state || {};
        const n = entryPart("h-tool-" + p.id, { name: p.tool || "tool", detail: st.title || argOf(st.input) });
        countTool();
        const out = st.output || (typeof st.result === "string" ? st.result : "");
        let html = "";
        if (st.input && Object.keys(st.input).length) html += payload("input", JSON.stringify(st.input, null, 2));
        if (out) html += payload("output", out);
        const stopped = st.status === "error" && isAbort({ message: st.error });
        if (st.error && !stopped) html += `<div class="entry-error" dir="auto">${esc(st.error)}</div>`;
        n.body.innerHTML = html;
        n.disclosable(!!html);
        n.state(stopped ? "held" : st.status === "error" ? "fail" : st.status === "completed" ? "ok" : "plain");
        if (stopped) n.detail.textContent = "stopped";
        else if (st.status === "error") n.open = true;
        if (st.time?.start && st.time?.end) {
          n.dur.textContent = ((st.time.end - st.time.start) / 1000).toFixed(1) + "s";
          if (state.turn && !state.turn.done) {
            if (!state.turn.ts0) state.turn.ts0 = st.time.start;
            state.turn.ts1 = st.time.end;
          }
        }
        break;
      }

      case "file":
        addRow(filesHtml([{ name: p.filename, uri: p.url, mime: p.mime }]));
        break;

      default:
        break;
    }
  }

  if (info.error) {
    addRow(`<div class="err-box" dir="auto">${esc(info.error.message || info.error.data?.message || JSON.stringify(info.error))}</div>`);
  }
  endTurn();
}

/* Rewound messages stay in the durable log — opencode's own clients hide them
   too. Each committed revert drops its message and everything after it. */
export function visibleEvents(events) {
  let list = events;
  for (const ev of events) {
    if (ev.type !== "session.next.revert.committed" || !ev.data?.messageID) continue;
    const at = list.findIndex((e) =>
      e.type === "session.next.prompted" && e.data?.messageID === ev.data.messageID);
    if (at >= 0) list = list.slice(0, at);
  }
  return list;
}
