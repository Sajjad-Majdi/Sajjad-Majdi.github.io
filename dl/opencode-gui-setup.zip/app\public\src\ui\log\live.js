/* Drawing the live stream.

   One event in, one change to the log out. Replayed history goes through the
   very same function, so what you scroll back to looks like what you watched. */

import { esc } from "../../core/dom.js";
import { argOf, isAbort } from "../../core/format.js";
import { finishText, mdRender } from "../../core/markdown.js";
import state from "../../core/store.js";
import { addRow, keepPinned } from "./dom.js";
import { entryPart, payload, textPart } from "./entries.js";
import { countTool, endTurn, markTime, noteStep, touchTurn, turnSay } from "./turn.js";
import { filesHtml, promptActions } from "./parts.js";

export function renderLiveEvent(ev) {
  const d = ev.data || {};
  markTime(d.timestamp);
  touchTurn();

  switch (ev.type) {
    case "session.next.prompted": {
      endTurn();
      const pfiles = (d.prompt?.files || []).map((f) => ({ name: f.name, uri: f.uri, mime: f.mime }));
      const row = addRow(
        `<div class="bubble" dir="auto">${filesHtml(pfiles)}${mdRender(d.prompt?.text || "")}</div>${promptActions()}`,
        "user");
      row._msg = { id: d.messageID || null, text: d.prompt?.text || "", files: pfiles };
      break;
    }

    case "session.next.step.started":
      noteStep();
      break;

    case "session.next.text.started":
      textPart("txt-" + d.textID);
      turnSay("Writing…");
      break;

    case "session.next.text.delta": {
      const n = textPart("txt-" + d.textID);
      if (d.delta) { n.buf += d.delta; n.el.appendChild(document.createTextNode(d.delta)); }
      keepPinned();
      break;
    }

    case "session.next.text.ended": {
      const n = textPart("txt-" + d.textID);
      if (d.text && d.text !== n.buf) n.buf = d.text;
      if (n.buf) { finishText(n.el, n.buf); n.done = true; }
      break;
    }

    case "session.next.reasoning.started":
      thought(d.reasoningID, d.timestamp);
      turnSay("Thinking…");
      break;

    case "session.next.reasoning.delta": {
      const n = thought(d.reasoningID, d.timestamp);
      if (d.delta) {
        n.body.firstChild.appendChild(document.createTextNode(d.delta));
        n.disclosable(true);
      }
      keepPinned();
      break;
    }

    case "session.next.reasoning.ended": {
      const n = thought(d.reasoningID, d.timestamp);
      if (d.text) finishText(n.body.firstChild, d.text);
      const has = !!n.body.firstChild.textContent.trim();
      n.disclosable(has);
      if (!has) n.open = false;
      const secs = ((d.timestamp || Date.now()) - n.t0) / 1000;
      n.name.textContent = secs >= 0.1 ? `thought for ${secs.toFixed(1)}s` : "thought";
      n.state("plain");
      if (!n.touched) n.open = false;   // it closes itself once the thinking is over
      break;
    }

    case "session.next.tool.called": {
      const n = entryPart("tool-" + d.callID, { name: d.tool || "tool", detail: argOf(d.input), t0: d.timestamp });
      countTool();
      turnSay((d.tool || "tool") + (argOf(d.input) ? " · " + argOf(d.input).slice(0, 60) : ""));
      n.input = d.input;
      n.body.innerHTML = d.input && Object.keys(d.input).length ? payload("input", JSON.stringify(d.input, null, 2)) : "";
      n.disclosable(!!n.body.innerHTML);
      break;
    }

    case "session.next.tool.progress": {
      const n = state.nodes.get("tool-" + d.callID);
      if (n && d.message) {
        n.detail.textContent = String(d.message).slice(0, 180);
        turnSay(String(d.message).slice(0, 70));
      }
      break;
    }

    case "session.next.tool.success": {
      const n = entryPart("tool-" + d.callID, { name: d.tool || "tool" });
      n.state("ok");
      const took = ((d.timestamp || Date.now()) - n.t0) / 1000;
      if (took >= 0.05) n.dur.textContent = took.toFixed(1) + "s";
      const out = liveToolOutput(d);
      if (out) n.body.insertAdjacentHTML("beforeend", payload("output", out));
      n.disclosable(!!n.body.innerHTML);
      break;
    }

    case "session.next.tool.failed": {
      const n = entryPart("tool-" + d.callID, { name: d.tool || "tool" });
      const stopped = isAbort(d.error);
      n.state(stopped ? "held" : "fail");
      if (stopped) {
        n.detail.textContent = "stopped";
        n.disclosable(!!n.body.innerHTML);
      } else {
        n.body.insertAdjacentHTML("beforeend",
          `<div class="entry-error" dir="auto">${esc(d.error?.message || JSON.stringify(d.error || {}, null, 2))}</div>`);
        n.disclosable(true);
        n.open = true;
      }
      break;
    }

    case "session.next.step.failed":
    case "session.error":
      if (isAbort(d.error)) addRow(`<p class="note-box">Stopped.</p>`);
      else addRow(`<div class="err-box" dir="auto">${esc(d.error?.message || d.error?.data?.message || JSON.stringify(d.error || {}))}</div>`);
      state.nodes.delete("body");
      break;

    case "session.next.retried":
      addRow(`<p class="note-box">Retrying${d.attempt ? " — attempt " + esc(d.attempt) : ""}…</p>`);
      break;

    case "session.next.compaction.started":
      addRow(`<p class="note-box">Compacting the context…</p>`);
      break;

    case "session.next.compaction.ended":
      addRow(`<p class="note-box">Context compacted.</p>`);
      break;

    default:
      break;
  }
}

/* the model's own working — open while it is happening, closed once it is over */
function thought(id, t0) {
  const key = "rsn-" + id;
  const existing = state.nodes.get(key);
  if (existing && existing.el.isConnected) return existing;
  const n = entryPart(key, { name: "thinking", think: true, t0 });
  n.body.innerHTML = `<div class="thought" dir="auto"></div>`;
  n.disclosable(false);
  return n;
}

function liveToolOutput(d) {
  if (Array.isArray(d.content)) {
    const parts = d.content.map((c) => (typeof c === "string" ? c : c.text || c.output || "")).filter(Boolean);
    if (parts.length) return parts.join("\n");
  }
  if (typeof d.result === "string") return d.result;
  if (d.structured && Object.keys(d.structured).length) return JSON.stringify(d.structured, null, 2);
  if (Array.isArray(d.outputPaths) && d.outputPaths.length) return d.outputPaths.join("\n");
  return "";
}
