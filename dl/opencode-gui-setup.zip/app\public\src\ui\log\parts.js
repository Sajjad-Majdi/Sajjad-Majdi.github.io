/* Small pieces of markup shared by the live stream and the replayed history. */

import { esc } from "../../core/dom.js";
import { baseName, isImage, localSrc } from "../../core/format.js";

export const promptActions = () =>
  `<span class="msg-actions">` +
    `<button type="button" class="mini-btn" data-act="copy" title="Copy"><i data-lucide="copy"></i></button>` +
    `<button type="button" class="mini-btn" data-act="rewind" title="Edit from here (rewind)"><i data-lucide="pencil"></i></button>` +
  `</span>`;

export function filesHtml(files) {
  if (!files || !files.length) return "";
  return `<div class="att-row">` + files.map((f) => {
    const src = localSrc(f.uri);
    return isImage(f.name || f.uri) || /^image\//.test(f.mime || "")
      ? `<img class="att-thumb" src="${esc(src)}" alt="${esc(f.name || "attachment")}" data-full="${esc(src)}">`
      : `<span class="att-file">${esc(f.name || baseName(f.uri))}</span>`;
  }).join("") + `</div>`;
}
