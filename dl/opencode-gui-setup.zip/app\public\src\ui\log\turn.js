/* One turn of work, collapsed to a single live line.

   A turn is everything the agent does between your message and its answer:
   thinking, tool calls, the running commentary in between. Shown as a stack of
   separate blocks it drowns the answer, so it collapses to one line that says
   what is happening right now, and opens to the whole chain in order. */

import state from "../../core/store.js";
import { finishText } from "../../core/markdown.js";
import { logEl, keepPinned } from "./dom.js";

export function startTurn() {
  endTurn();
  const row = document.createElement("div");
  row.className = "row";
  row.innerHTML =
    '<section class="chain">' +
      '<button type="button" class="chain-head">' +
        '<span class="chain-mark"></span>' +
        '<span class="chain-label">Working…</span>' +
        '<span class="chain-meta"></span>' +
        '<svg class="chain-caret lucide" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>' +
      "</button>" +
      '<div class="chain-body" hidden></div>' +
    "</section>";
  logEl().appendChild(row);

  const chain = row.querySelector(".chain");
  const body = row.querySelector(".chain-body");
  const head = row.querySelector(".chain-head");
  const turn = {
    row, chain, body,
    label: row.querySelector(".chain-label"),
    meta: row.querySelector(".chain-meta"),
    t0: Date.now(),
    tLast: Date.now(),      // when this turn last saw anything happen
    steps: 0,
    tools: 0,
    texts: [],
    touched: false,
    done: false,
    open(v) {
      body.hidden = !v;
      chain.classList.toggle("open", v);
    },
  };
  head.onclick = () => { turn.touched = true; turn.open(body.hidden); };
  state.turn = turn;
  state.nodes.delete("body");
  keepPinned();
  return turn;
}

/* Any sign of life in the open turn. A turn with no sign of life and an idle
   session was cut off — the closing event never came. */
export function touchTurn() {
  if (state.turn && !state.turn.done) state.turn.tLast = Date.now();
}

export function turnSay(text) {
  if (state.turn && !state.turn.done) state.turn.label.textContent = text;
}

/* count a step, starting a turn if this is the first thing that happened */
export function noteStep() {
  logEl().querySelector(".row.empty-note")?.remove();
  if (!state.turn || state.turn.done) startTurn();
  state.turn.steps += 1;
}

export function countTool() {
  if (state.turn && !state.turn.done) state.turn.tools += 1;
}

/* replayed events carry their own clock; a turn is timed by them, not by when
   the browser happened to draw it */
export function markTime(ts) {
  const t = state.turn;
  if (!t || t.done || !ts) return;
  if (!t.ts0) t.ts0 = ts;
  t.ts1 = ts;
}

export function trackText(el) {
  if (state.turn && !state.turn.done) state.turn.texts.push(el);
}

export function chainBody() {
  if (!state.turn || state.turn.done) startTurn();
  return state.turn.body;
}

/* the answer is the last thing it said — lift that out of the working chain */
export function endTurn() {
  const t = state.turn;
  state.turn = null;
  state.nodes.delete("body");
  if (!t || t.done) return;
  t.done = true;

  /* Streaming text without a closing event stays plain — render it now. */
  for (const [k, n] of state.nodes) {
    if (k.startsWith("txt-") && n.buf && !n.done && n.el.isConnected) {
      finishText(n.el, n.buf);
      n.done = true;
    }
  }

  /* the answer is lifted clear of the chain — it lives in its own row, or the
     move would be a no-op because it already sits inside the chain's row */
  const answer = t.texts.filter((el) => el.isConnected && el.textContent.trim()).pop();
  if (answer) {
    const row = document.createElement("div");
    row.className = "row";
    const msg = document.createElement("div");
    msg.className = "msg";
    const body = document.createElement("div");
    body.className = "msg-body";
    body.appendChild(answer);
    msg.appendChild(body);
    row.appendChild(msg);
    t.row.after(row);
  }

  const span = t.ts0 && t.ts1 && t.ts1 > t.ts0 ? t.ts1 - t.ts0 : Date.now() - t.t0;
  const secs = (span / 1000).toFixed(1);
  const worked = t.tools > 0;
  t.label.textContent = worked ? "Worked for " + secs + "s" : "Thought for " + secs + "s";
  t.meta.textContent = worked ? t.tools + (t.tools === 1 ? " step" : " steps") : "";
  t.chain.classList.add("settled");
  if (!t.touched) t.open(false);

  /* nothing happened in there — do not leave an empty disclosure behind */
  if (!t.body.querySelector(".entry, .assistant")) t.row.remove();
}
