/* The conversation view: opening a session and keeping its log honest. */

import bus from "../../core/bus.js";
import { $, esc } from "../../core/dom.js";
import state, { isWorking, setCurrent } from "../../core/store.js";
import { dirExists } from "../../services/dirs.js";
import { fetchHistory, fetchMessages, fetchSession } from "../../services/sessions.js";
import { E } from "../../services/stream.js";
import { endDraft } from "../draft.js";
import { syncPickers } from "../pickers.js";
import { toast } from "../toast.js";
import { loadPending } from "./approvals.js";
import { addRow, clearLog, logEl, scrollToEnd, settleRunning } from "./dom.js";
import { renderMessage, visibleEvents } from "./history.js";
import { renderLiveEvent } from "./live.js";
import { endTurn } from "./turn.js";

export function showEmpty() {
  endDraft();
  setCurrent(null);
  $("empty").hidden = false;
  $("workspace").hidden = true;
}

export async function openSession(id) {
  endDraft();
  setCurrent(id);
  state.nodes.clear();
  state.turn = null;
  state.pinned = true;
  $("empty").hidden = true;
  $("workspace").hidden = false;
  $("btn-bottom").hidden = true;
  logEl().innerHTML =
    `<div class="row log-skeleton"><span class="sk w1"></span><span class="sk w2"></span><span class="sk w3"></span></div>`;

  try { await fetchSession(id); } catch {}
  if (id !== state.cur) return;
  const dir = state.sessions.get(id)?.location?.directory;
  if (dir) dirExists(dir, { fresh: true });
  syncPickers();

  /* Replay. Newer sessions keep a durable event log — replaying it through the
     same renderer the live stream uses means history and live look identical.
     Sessions written by older opencode builds only have the message store, so
     fall back to that. */
  let events = [];
  try { events = await fetchHistory(id); } catch { events = []; }
  if (id !== state.cur) return;

  let messages = [];
  if (!events.length) {
    try {
      messages = await fetchMessages(id);
    } catch (e) {
      clearLog();
      addRow(`<div class="err-box" dir="auto">Could not load this conversation — ${esc(e.message)}</div>`);
      return;
    }
  }
  if (id !== state.cur) return;

  clearLog();
  if (events.length) {
    state.pinned = false;                    // no scroll work while the past is drawn
    for (const ev of visibleEvents(events)) renderLiveEvent(ev);
    endTurn();
    state.pinned = true;
    state.nodes.delete("body");
    if (!isWorking(id)) settleRunning();
  } else if (Array.isArray(messages) && messages.length) {
    for (const m of messages) renderMessage(m);
    endTurn();
  } else {
    addRow(`<p class="note-box">No messages yet — send the first one below.</p>`, "empty-note");
  }
  scrollToEnd(true);
  loadPending(id);
  $("prompt").focus();
}

/* A turn that ends while we are watching gets tidied up here. */
export function settleOpenTurn(reason) {
  settleRunning(reason);
  endTurn();
}

export function mountConversation() {
  bus.on(E.live, (ev) => renderLiveEvent(ev));
  bus.on(E.idle, () => settleOpenTurn());
  bus.on(E.gone, () => showEmpty());
  bus.on(E.reverted, (sid) => { toast("Session rewound"); openSession(sid); });

  const log = logEl();
  log.onscroll = () => {
    state.pinned = log.scrollHeight - log.scrollTop - log.clientHeight < 100;
    $("btn-bottom").hidden = state.pinned;
  };
  $("btn-bottom").onclick = () => scrollToEnd(true);
}
