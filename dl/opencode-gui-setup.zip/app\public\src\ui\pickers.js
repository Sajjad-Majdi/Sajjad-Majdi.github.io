/* The chips in the message box: folder, model, thinking level, agent.

   On a draft they set what the session will be created with; on an open session
   they change it live. Either way they read the store and write the store. */

import bus from "../core/bus.js";
import { $, coalesce } from "../core/dom.js";
import { baseName, modelKey } from "../core/format.js";
import state, { T, currentSession, patchDraft, patchSession } from "../core/store.js";
import { findModel, levelOptions, modelOptions, variantsOf } from "../services/catalog.js";
import { remember } from "../services/prefs.js";
import { setSessionAgent, setSessionModelApi } from "../services/sessions.js";
import { openFolderPop } from "./folderpicker.js";
import { openPop } from "./popover.js";
import { toast } from "./toast.js";

const label = (btn, text) => { btn.querySelector(".chip-label").textContent = text; };

export const currentModelKey = () =>
  state.draft ? state.draft.model : modelKey(currentSession()?.model);
export const currentVariant = () =>
  (state.draft ? state.draft.variant : currentSession()?.model?.variant) || "default";
export const currentAgent = () =>
  state.draft ? state.draft.agent : currentSession()?.agent || "build";

export function syncPickers() {
  const draft = state.draft;
  const s = draft ? null : currentSession();
  const key = draft ? draft.model : modelKey(s?.model);
  const model = findModel(key);
  const vs = variantsOf(model);

  /* A stored variant may no longer be offered (unknown level, or refused by
     the server before). Never display a level the picker cannot offer. */
  let variant = draft ? draft.variant : s?.model?.variant;
  if (variant && variant !== "default" && !vs.includes(variant)) {
    if (draft) { draft.variant = "default"; remember({ variant: "default" }); }
    variant = "default";
  }

  label($("pick-model"), model ? model.name || model.id : key ? key.split("/").pop() : "select model");
  $("pick-model").title = key || "Model";

  const pv = $("pick-variant");
  label(pv, variant && variant !== "default" ? variant : "default");
  pv.disabled = !vs.length;
  pv.title = vs.length ? "Thinking level" : "This model has no thinking levels";

  label($("pick-agent"), draft ? draft.agent : s?.agent || "build");

  const pd = $("pick-dir");
  pd.hidden = !draft;
  if (draft) {
    label(pd, baseName(draft.dir) || draft.dir || "folder");
    pd.title = draft.dir || "Working directory";
  }
}

const scheduleSync = coalesce(syncPickers);

export async function setSessionModel(key, variant) {
  if (!key) return;
  remember({ model: key, variant: variant || "default" });
  if (state.draft) {
    patchDraft({ model: key, variant: variant || "default" });
    return;
  }
  const s = currentSession();
  if (!s) return;
  const i = key.indexOf("/");
  const model = { providerID: key.slice(0, i), id: key.slice(i + 1) };
  if (variant && variant !== "default") model.variant = variant;
  try {
    await setSessionModelApi(state.cur, model);
    patchSession(s.id, { model: { ...model, variant: variant || "default" } });
  } catch (e) { toast("Could not switch model — " + e.message, true); }
}

async function setAgent(v) {
  remember({ agent: v });
  if (state.draft) { patchDraft({ agent: v }); return; }
  try {
    await setSessionAgent(state.cur, v);
    patchSession(state.cur, { agent: v });
  } catch (err) { toast("Could not switch agent — " + err.message, true); }
}

export function mountPickers() {
  $("pick-model").onclick = (e) =>
    openPop(e.currentTarget, {
      options: modelOptions,
      value: currentModelKey(),
      onPick: (v) => setSessionModel(v, "default"),
    });

  $("pick-variant").onclick = (e) => {
    const vs = variantsOf(findModel(currentModelKey()));
    if (!vs.length) return;
    openPop(e.currentTarget, {
      searchable: false,
      value: currentVariant(),
      options: () => levelOptions(vs),
      onPick: (v) => setSessionModel(currentModelKey(), v),
    });
  };

  $("pick-agent").onclick = (e) =>
    openPop(e.currentTarget, {
      searchable: false,
      value: currentAgent(),
      options: () => [{ group: "", items: state.agents.map((a) => ({ value: a.id, label: a.id })) }],
      onPick: setAgent,
    });

  $("pick-dir").onclick = (e) => openFolderPop(e.currentTarget);
  /* Drop a folder straight onto the chip — no dialog, no prompt. */
  $("pick-dir").addEventListener("dragover", (e) => { if (state.draft) e.preventDefault(); });
  $("pick-dir").addEventListener("drop", (e) => {
    if (!state.draft) return;
    e.preventDefault();
    bus.emit("folder:dropped", e.dataTransfer);
  });

  for (const topic of [T.draft, T.current, T.sessions, T.catalog]) bus.on(topic, scheduleSync);
}
