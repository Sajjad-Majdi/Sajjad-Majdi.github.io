/* The one floating list: model, thinking level, agent, folder.

   It is given options (a list, or a function of the search term) and a callback.
   It knows nothing about what it is listing. */

import { $, esc, icons } from "../core/dom.js";

const POP = { anchor: null, onPick: null, onAction: null, optionsFn: null, flat: [], cursor: 0, value: null };

export const popAnchor = () => POP.anchor;
export const isPopOpen = () => !$("pop").hidden;

export function openPop(anchor, { options, value, searchable = true, actions = null, placeholder = null, onPick, onAction }) {
  const pop = $("pop");
  POP.anchor = anchor;
  POP.onPick = onPick;
  POP.onAction = onAction || null;
  POP.value = value;
  POP.optionsFn = typeof options === "function" ? options : () => options;
  $("pop-search-wrap").hidden = !searchable;
  $("pop-search").value = "";
  $("pop-search").placeholder = placeholder || "Search";

  const bar = $("pop-actions");
  if (actions && actions.length) {
    bar.hidden = false;
    bar.innerHTML = actions.map((a, i) =>
      `<button type="button" class="pop-action" data-a="${i}"><i data-lucide="${esc(a.icon || "folder")}"></i><span>${esc(a.label)}</span></button>`
    ).join("");
    bar.querySelectorAll(".pop-action").forEach((b) => {
      b.onclick = () => { if (POP.onAction) POP.onAction(Number(b.dataset.a)); };
    });
  } else {
    bar.hidden = true;
    bar.innerHTML = "";
  }

  pop.hidden = false;
  anchor.setAttribute("aria-expanded", "true");
  fillPop("");
  positionPop();
  if (searchable) $("pop-search").focus();
  markCursor(true);
  setTimeout(() => document.addEventListener("mousedown", outsidePop), 0);
}

export function positionPop() {
  const pop = $("pop");
  if (!POP.anchor) return;
  const r = POP.anchor.getBoundingClientRect();
  const w = pop.offsetWidth, h = pop.offsetHeight;
  /* Clamp inside the viewport on both axes — on narrow windows the old math
     went negative and the picker slid off-screen. */
  const left = Math.min(Math.max(8, r.left), Math.max(8, window.innerWidth - w - 8));
  let top = r.top - h - 8;
  if (top < 8) top = Math.min(r.bottom + 8, Math.max(8, window.innerHeight - h - 8));
  pop.style.left = left + "px";
  pop.style.top = Math.max(8, top) + "px";
}

export function fillPop(term) {
  const groups = POP.optionsFn(term) || [];
  POP.flat = [];
  const html = groups.map((g) => {
    const head = g.group ? `<div class="pop-group">${esc(g.group)}</div>` : "";
    return head + g.items.map((it) => {
      const i = POP.flat.length;
      POP.flat.push(it);
      return `<div class="pop-item" role="option" data-i="${i}" aria-selected="${it.value === POP.value}">
  <i class="pi-check" data-lucide="check"></i>
  <span class="pi-name">${esc(it.label)}</span>
  ${it.note ? `<span class="pi-note">${esc(it.note)}</span>` : ""}
</div>`;
    }).join("");
  }).join("");
  $("pop-list").innerHTML = html || `<p class="pop-empty">No match</p>`;
  icons();
  const sel = POP.flat.findIndex((x) => x.value === POP.value);
  POP.cursor = sel >= 0 ? sel : 0;
  markCursor();
}

function markCursor(scroll) {
  const items = [...$("pop-list").querySelectorAll(".pop-item")];
  items.forEach((el, i) => el.classList.toggle("on", i === POP.cursor));
  if (scroll && items[POP.cursor]) items[POP.cursor].scrollIntoView({ block: "nearest" });
}

export function closePop() {
  const pop = $("pop");
  pop.hidden = true;
  pop.ondragover = null;
  pop.ondrop = null;
  if (POP.anchor) POP.anchor.setAttribute("aria-expanded", "false");
  document.removeEventListener("mousedown", outsidePop);
  POP.anchor = null;
}

function outsidePop(e) {
  if (!$("pop").contains(e.target) && POP.anchor && !POP.anchor.contains(e.target)) closePop();
}

function choosePop(i) {
  const it = POP.flat[i];
  if (!it) return;
  const cb = POP.onPick;
  closePop();
  if (cb) cb(it.value, it);
}

export function popKeys(e) {
  if (e.key === "ArrowDown" || e.key === "ArrowUp") {
    e.preventDefault();
    if (!POP.flat.length) return;
    POP.cursor = (POP.cursor + (e.key === "ArrowDown" ? 1 : -1) + POP.flat.length) % POP.flat.length;
    markCursor(true);
  } else if (e.key === "Enter") {
    e.preventDefault();
    choosePop(POP.cursor);
  } else if (e.key === "Escape") {
    e.preventDefault();
    closePop();
  }
}

export function mountPopover() {
  $("pop-search").oninput = (e) => fillPop(e.target.value);
  $("pop-search").onkeydown = popKeys;
  $("pop").onkeydown = popKeys;
  $("pop-list").onclick = (e) => {
    const it = e.target.closest(".pop-item");
    if (it) choosePop(Number(it.dataset.i));
  };
  $("pop-list").onmousemove = (e) => {
    const it = e.target.closest(".pop-item");
    if (it) { POP.cursor = Number(it.dataset.i); markCursor(); }
  };
  window.addEventListener("resize", () => { if (isPopOpen()) positionPop(); });
}
