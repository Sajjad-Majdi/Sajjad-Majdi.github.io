/* Keyboard. Ctrl+N new chat, Ctrl+K search, Ctrl+M model, Ctrl+B sidebar,
   Esc closes what is open. */

import { $ } from "../core/dom.js";
import state from "../core/store.js";
import { startDraft } from "./draft.js";
import { closeLightbox, isLightboxOpen } from "./lightbox.js";
import { closePop, isPopOpen } from "./popover.js";

export function mountShortcuts() {
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      if (isPopOpen()) return closePop();
      if (isLightboxOpen()) return closeLightbox();
    }
    const mod = e.ctrlKey || e.metaKey;
    if (!mod) return;
    const k = e.key.toLowerCase();
    if (k === "n") { e.preventDefault(); startDraft(); }
    else if (k === "k") { e.preventDefault(); $("filter").focus(); $("filter").select(); }
    else if (k === "m" && (state.cur || state.draft)) { e.preventDefault(); $("pick-model").click(); }
    else if (k === "b") { e.preventDefault(); $("btn-menu").click(); }
  });
}
