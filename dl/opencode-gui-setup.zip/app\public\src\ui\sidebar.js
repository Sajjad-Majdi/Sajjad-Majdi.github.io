/* The session list.

   It draws from the store and nothing else: every event that could change a row
   ends as a store change, and this repaints on the next frame. */

import bus from "../core/bus.js";
import { $, coalesce, esc, icons } from "../core/dom.js";
import { ago, baseName, modelKey, titleOf } from "../core/format.js";
import state, {
  T, isAsking, isBusy, isDirGone, isWorking, lastActivity, setFilter, setScope, statusOf,
} from "../core/store.js";
import { deleteSession } from "./actions.js";
import { startDraft } from "./draft.js";
import { openSession } from "./log/view.js";
import { nav as navPref } from "../services/prefs.js";

function visibleSessions() {
  const q = state.filter.toLowerCase();
  return [...state.sessions.values()]
    .filter((s) => {
      if (state.scope === "active" && !isWorking(s.id)) return false;
      if (!q) return true;
      return (
        (s.title || "").toLowerCase().includes(q) ||
        (s.location?.directory || "").toLowerCase().includes(q) ||
        modelKey(s.model).toLowerCase().includes(q)
      );
    })
    .sort((a, b) => lastActivity(b) - lastActivity(a));
}

function rowHtml(s) {
  const st = statusOf(s.id);
  const gone = isDirGone(s);
  /* One mark, in one place: waiting on you, broken, working, or nothing. */
  const cls = isAsking(s.id) ? "dot ask"
    : st === "retry" || gone ? "dot err"
    : isBusy(s.id) ? "dot busy" : "dot";
  const where = [s.model?.id, baseName(s.location?.directory || s.directory), ago(lastActivity(s))]
    .filter(Boolean).join(" · ") + (gone ? " · folder no longer exists" : "");
  return `<article class="s-item${s.id === state.cur ? " sel" : ""}" data-id="${s.id}" tabindex="0" title="${esc(where)}">
  <div class="s-row">
    <span class="${cls}"></span>
    <span class="s-name" dir="auto">${esc(titleOf(s))}</span>
    ${isAsking(s.id) ? '<span class="s-ask">needs you</span>'
      : gone ? '<span class="s-gone">folder gone</span>' : ""}
  </div>
  <button type="button" class="s-kill" data-kill="${s.id}" title="Delete session"><i data-lucide="trash-2"></i></button>
</article>`;
}

function paint() {
  const list = $("session-list");
  const items = visibleSessions();

  if (!items.length) {
    list.innerHTML = `<p class="side-empty">${
      state.filter ? "No session matches that search."
        : state.scope === "active" ? "Nothing is running right now."
        : "No sessions yet."
    }</p>`;
  } else {
    list.innerHTML = items.map(rowHtml).join("");
    icons();
  }

  const busy = [...state.sessions.keys()].filter(isWorking).length;
  $("stat-total").textContent = state.sessions.size + (state.sessions.size === 1 ? " session" : " sessions");
  $("stat-busy").textContent = busy ? busy + " running" : "";
}

export const renderSidebar = coalesce(paint);

/* the drawer, on a narrow window */
const closeNav = () => { $("sidebar").classList.remove("open"); $("scrim").hidden = true; };
function setNav(hidden) {
  document.body.classList.toggle("nav-hidden", hidden);
  navPref.set(hidden);
  icons();
}

export function mountSidebar() {
  setNav(navPref.hidden());
  $("btn-collapse").onclick = () => setNav(true);
  $("btn-menu").onclick = () => {
    if (document.body.classList.contains("nav-hidden")) { setNav(false); return; }
    if (window.innerWidth <= 900) {
      const open = $("sidebar").classList.toggle("open");
      $("scrim").hidden = !open;
      return;
    }
    setNav(true);
  };
  $("scrim").onclick = closeNav;

  $("session-list").onclick = (e) => {
    const kill = e.target.closest(".s-kill");
    if (kill) { e.stopPropagation(); deleteSession(kill.dataset.kill); return; }
    const it = e.target.closest(".s-item");
    if (it) { openSession(it.dataset.id); if (window.innerWidth <= 900) closeNav(); }
  };
  $("session-list").onkeydown = (e) => {
    if (e.key !== "Enter" && e.key !== " ") return;
    const it = e.target.closest(".s-item");
    if (it) { e.preventDefault(); openSession(it.dataset.id); }
  };

  $("filter").oninput = (e) => setFilter(e.target.value.trim());
  document.querySelectorAll(".seg").forEach((b) => {
    b.onclick = () => {
      document.querySelectorAll(".seg").forEach((x) => x.classList.remove("active"));
      b.classList.add("active");
      setScope(b.dataset.scope);
    };
  });

  $("btn-new").onclick = startDraft;
  $("btn-new-2").onclick = startDraft;

  for (const topic of [T.sessions, T.status, T.asking, T.current, T.filter]) bus.on(topic, renderSidebar);
  /* relative times go stale on their own */
  setInterval(renderSidebar, 30000);
  renderSidebar();
}

export { closeNav, setNav };
