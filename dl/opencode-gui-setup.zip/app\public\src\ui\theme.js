import { $, icons } from "../core/dom.js";
import { theme as pref } from "../services/prefs.js";

export function applyTheme(t) {
  document.documentElement.dataset.theme = t;
  pref.set(t);
  const btn = $("btn-theme");
  if (btn) {
    btn.innerHTML = `<i data-lucide="${t === "dark" ? "sun" : "moon"}"></i>`;
    btn.title = t === "dark" ? "Switch to light" : "Switch to dark";
    icons();
  }
}

export const toggleTheme = () =>
  applyTheme(document.documentElement.dataset.theme === "dark" ? "light" : "dark");

export function mountTheme() {
  applyTheme(pref.get());
  $("btn-theme").onclick = toggleTheme;
}
