/* Asking the server to name a new session.

   opencode's own title agent is only reached from its v1 prompt path, and this
   app sends on v2 — the only path that emits the events the live view draws
   from. So the naming is ours to do, and the node server does it: a browser
   timer would die on the reload that so often follows a first message, and the
   rename comes back to every open page as session.updated anyway. */

import { STAMP_TITLE } from "../core/format.js";
import { gui } from "../core/api.js";
import state from "../core/store.js";

export function requestSessionName(id, text) {
  const first = String(text || "").split(/\r?\n/).map((l) => l.trim()).filter(Boolean)[0] || "";
  if (!first) return;
  const s = state.sessions.get(id);
  if (!s) return;
  const cur = String(s.title || "").trim();
  if (cur && !STAMP_TITLE.test(cur)) return;

  gui("/auto-title", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ id, text: first, directory: s.location?.directory || "" }),
  }).catch(() => {});
}
