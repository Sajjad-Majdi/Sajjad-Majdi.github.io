/* One line of feedback, bottom of the screen, gone in a few seconds. */

import { $ } from "../core/dom.js";

let timer = 0;

export function toast(msg, bad) {
  const t = $("toast");
  t.textContent = msg;
  t.className = "toast" + (bad ? " err" : "");
  t.hidden = false;
  clearTimeout(timer);
  timer = setTimeout(() => (t.hidden = true), 4500);
}
