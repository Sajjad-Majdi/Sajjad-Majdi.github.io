/* When a prompt is accepted and then nothing happens.

   The server can accept a prompt and never run it — an unavailable model
   variant, for instance, fails to drain with no error event, only a server log
   line. History then sticks at "prompted" and /session/active goes idle.
   Without this the UI shows only your bubble and an idle composer. So: check
   server truth after a delay, say what went wrong, and fall back to default. */

import { esc } from "../core/dom.js";
import { modelKey } from "../core/format.js";
import state, { clearStatus, isWorking, patchSession } from "../core/store.js";
import { fetchHistory, loadActive, setSessionModelApi } from "../services/sessions.js";
import { markVariantBad, remember } from "../services/prefs.js";
import { addRow } from "./log/dom.js";
import { settleOpenTurn } from "./log/view.js";

const STARTED = new Set([
  "session.next.step.started",
  "session.next.text.started",
  "session.next.tool.called",
  "session.error",
  "session.next.step.failed",
]);

export function watchPrompt(id) {
  const startedAt = Date.now();
  setTimeout(async () => {
    if (state.cur !== id) return;
    try { await loadActive(); } catch {}
    if (state.cur !== id || isWorking(id)) return;

    let types = [];
    try {
      types = (await fetchHistory(id, 100, 1)).map((e) => e.type);
    } catch { return; }
    if (state.cur !== id || isWorking(id)) return;
    if (types.some((t) => STARTED.has(t))) return;
    if (Date.now() - startedAt < 12000) return;

    const s = state.sessions.get(id);
    const variant = s?.model?.variant;
    if (variant && variant !== "default") markVariantBad(modelKey(s.model), variant);
    clearStatus(id);
    settleOpenTurn("no result");
    addRow(
      `<div class="err-box" dir="auto">The model did not start — ` +
      (variant && variant !== "default"
        ? `the “${esc(variant)}” thinking level is not offered for this model. It is now hidden, the session is back on “default” — send again.`
        : `the run produced no steps. Try sending again.`) +
      `</div>`
    );

    if (variant && variant !== "default" && s?.model) {
      try {
        await setSessionModelApi(id, { providerID: s.model.providerID, id: s.model.id || s.model.modelID });
        patchSession(id, { model: { ...s.model, variant: "default" } });
        remember({ variant: "default" });
      } catch {}
    }
  }, 15000);
}
