#!/usr/bin/env node
// opencode gui - lightweight web UI for opencode
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(__dirname, "public");
const UPLOADS = path.join(os.tmpdir(), "opencode-gui-uploads");
fs.mkdirSync(UPLOADS, { recursive: true });

// ---------- args ----------
const argv = process.argv.slice(2).filter((a) => a.toLowerCase() !== "gui");
function arg(name, def) {
  const i = argv.indexOf("--" + name);
  if (i !== -1 && argv[i + 1] && !argv[i + 1].startsWith("--")) return argv[i + 1];
  return def;
}
const GUI_PORT = Number(arg("port", process.env.OPENCODE_GUI_PORT || 7788));
const HOST = arg("hostname", "127.0.0.1");
const ATTACH = arg("attach", process.env.OPENCODE_GUI_ATTACH || null);
const NO_OPEN = argv.includes("--no-open");
const CWD = arg("cwd", process.cwd());

// The installer bakes the real path into OPENCODE_BIN. Without it, guess the
// usual npm location, and fall back to whatever PATH resolves.
function findOpencode() {
  if (process.env.OPENCODE_BIN) return process.env.OPENCODE_BIN;
  if (process.platform !== "win32") return "opencode";
  const guesses = [
    path.join(os.homedir(), "AppData", "Roaming", "npm", "opencode.cmd"),
    path.join(os.homedir(), ".opencode", "bin", "opencode.exe"),
    path.join(os.homedir(), "AppData", "Local", "Programs", "opencode", "opencode.exe"),
  ];
  for (const g of guesses) if (fs.existsSync(g)) return g;
  return "opencode";
}
const OPENCODE_BIN = findOpencode();

let upstream = ATTACH ? ATTACH.replace(/\/+$/, "") : null;
let child = null;

// ---------- start / attach opencode server ----------
function startServer() {
  return new Promise((resolve, reject) => {
    const args = ["serve", "--hostname", "127.0.0.1", "--port", "0"];
    const win = process.platform === "win32";
    child = win
      ? spawn(process.env.ComSpec || "cmd.exe", ["/d", "/s", "/c", OPENCODE_BIN, ...args], {
          cwd: CWD,
          windowsVerbatimArguments: false,
          stdio: ["ignore", "pipe", "pipe"],
        })
      : spawn(OPENCODE_BIN, args, { cwd: CWD, stdio: ["ignore", "pipe", "pipe"] });
    let buf = "";
    const onData = (d) => {
      buf += d.toString();
      const m = buf.match(/https?:\/\/[\d.]+:(\d+)/);
      if (m) {
        child.stdout.off("data", onData);
        child.stderr.off("data", onData);
        resolve(m[0].replace(/\/+$/, ""));
      }
    };
    child.stdout.on("data", onData);
    child.stderr.on("data", onData);
    child.on("error", reject);
    child.on("exit", (c) => {
      if (!upstream) reject(new Error("opencode serve exited with code " + c));
      else if (!stopping && !ATTACH) restartUpstream(c);
    });
    setTimeout(() => reject(new Error("timed out waiting for opencode server")), 30000);
  });
}

let stopping = false;
let restartTimer = null;
function restartUpstream(code) {
  if (restartTimer) return;
  process.stdout.write("opencode server exited (" + code + ") — restarting…\n");
  restartTimer = setTimeout(async () => {
    restartTimer = null;
    try {
      upstream = await startServer();
      process.stdout.write("opencode api: " + upstream + "\n");
    } catch (e) {
      process.stdout.write("restart failed: " + e.message + "\n");
      restartUpstream("retry");
    }
  }, 1200);
}

function shutdown() {
  stopping = true;
  if (child && !child.killed) {
    try {
      if (process.platform === "win32")
        spawn("taskkill", ["/pid", String(child.pid), "/f", "/t"], { stdio: "ignore" });
      else child.kill("SIGTERM");
    } catch {}
  }
  process.exit(0);
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);

// ---------- static ----------
const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif": "image/gif",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".woff2": "font/woff2",
  ".json": "application/json",
  ".pdf": "application/pdf",
  ".txt": "text/plain; charset=utf-8",
  ".md": "text/plain; charset=utf-8",
};

const notFound = (res) => {
  res.writeHead(404, { "content-type": "text/plain" });
  res.end("not found");
};

function serveStatic(req, res) {
  let p = decodeURIComponent(req.url.split("?")[0]);
  if (p === "/") p = "/index.html";
  const file = path.join(PUBLIC, path.normalize(p).replace(/^[/\\]+/, ""));
  if (!file.startsWith(PUBLIC)) return notFound(res);
  fs.readFile(file, (err, data) => {
    if (err) return notFound(res);
    res.writeHead(200, {
      "content-type": MIME[path.extname(file)] || "application/octet-stream",
      "cache-control": "no-cache",
    });
    res.end(data);
  });
}

// ---------- naming a session ----------
/* opencode names a session from an internal "title" agent, but only on its v1
   prompt path. The v2 endpoint this app sends on runs the same turn and never
   reaches that agent, so a session sent from here would keep the timestamp it
   was created with for ever. We cannot switch to v1: it emits the old
   message.* events, not the session.next.* ones the live view is built on, so
   the first answer would arrive as a blank screen.

   So name it ourselves. opencode exposes a stateless namer — the one it uses
   for project copies — which runs the small model and returns a slug. No
   session is created, so nothing flashes in the sidebar. If it fails, or hands
   back one of its random two-word names, the first line of the message does
   the job.

   This waits here rather than in the page because a reload would lose a
   browser timer, and the rename reaches every open page as session.updated. */
const TITLE_DELAY = Number(process.env.OPENCODE_GUI_TITLE_DELAY || 1200);
const STAMP_TITLE = /^(?:new|child) session\s*[-–—]?\s*\d{4}-\d{2}-\d{2}T[\d:.]+Z?$/i;
const naming = new Set();

async function ocJson(upath, opts) {
  const r = await fetch(upstream + upath, opts);
  const t = await r.text();
  if (!r.ok) throw new Error("opencode " + r.status + " " + t.slice(0, 200));
  return t ? JSON.parse(t) : null;
}

const words = (s) => String(s).toLowerCase().match(/[a-zÀ-ɏ؀-ۿ]{3,}/g) || [];

/* The namer answers a random name when it has no context or no model to run.
   A real name always echoes something from the text, so ask it to. */
function titleFromSlug(slug, context) {
  const parts = String(slug || "").split(/[-_\s]+/).filter(Boolean);
  if (parts.length < 2) return "";
  const seen = new Set(words(context));
  const echoes = parts.some((w) => {
    const lower = w.toLowerCase();
    for (const c of seen) if (c.startsWith(lower) || lower.startsWith(c)) return true;
    return false;
  });
  if (!echoes) return "";
  return parts.join(" ").replace(/^./, (c) => c.toUpperCase());
}

async function nameSession(id, line, directory) {
  naming.delete(id);
  try {
    const session = (await ocJson("/api/session/" + id))?.data;
    if (!session) return;
    if (session.title && !STAMP_TITLE.test(String(session.title).trim())) return;

    let title = "";
    if (session.projectID) {
      try {
        const q = directory ? "?directory=" + encodeURIComponent(directory) : "";
        const r = await ocJson("/experimental/project/" + session.projectID + "/copy/generate-name" + q, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ context: line.slice(0, 400) }),
        });
        title = titleFromSlug(r?.name, line);
      } catch {
        /* rate limited, or no small model — the first line still works */
      }
    }
    if (!title) title = line.length > 60 ? line.slice(0, 60).trimEnd() + "…" : line;

    /* Something may have named it while the model was thinking. */
    const now = String((await ocJson("/api/session/" + id))?.data?.title || "").trim();
    if (now && !STAMP_TITLE.test(now)) return;

    /* Rename goes to the v1 store. The v2 path answers the SPA page with 200,
       which reads as success and renames nothing — the same trap as delete. */
    await ocJson("/session/" + id + (directory ? "?directory=" + encodeURIComponent(directory) : ""), {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ title }),
    });
  } catch {
    /* The session may be gone, or opencode with it. Nothing left to name. */
  }
}

async function handleAutoTitle(req, res) {
  try {
    const body = JSON.parse((await readBody(req, 64 * 1024)).toString() || "{}");
    const id = String(body.id || "");
    const line = String(body.text || "").trim();
    if (!/^ses/.test(id) || !line) throw new Error("need a session id and some text");
    if (naming.has(id)) return json(res, 202, { naming: true });
    naming.add(id);
    setTimeout(() => nameSession(id, line, String(body.directory || "")), TITLE_DELAY).unref();
    json(res, 202, { naming: true });
  } catch (e) {
    json(res, 400, { error: "bad_request", message: e.message });
  }
}

// ---------- proxy to opencode ----------
function proxy(req, res) {
  const target = new URL(upstream);
  const upath = req.url.replace(/^\/oc/, "");
  const headers = { ...req.headers };
  delete headers.host;
  delete headers["accept-encoding"];
  const preq = http.request(
    {
      hostname: target.hostname,
      port: target.port,
      path: upath,
      method: req.method,
      headers,
    },
    (pres) => {
      const h = { ...pres.headers };
      const sse = (h["content-type"] || "").includes("text/event-stream");
      if (sse) {
        h["cache-control"] = "no-cache, no-transform";
        h["x-accel-buffering"] = "no";
      }
      res.writeHead(pres.statusCode || 502, h);
      if (sse) {
        /* Every byte matters here: Nagle batches the small SSE frames into
           bursts, which is what makes a live agent look frozen and then jump. */
        res.flushHeaders();
        pres.socket?.setNoDelay(true);
        res.socket?.setNoDelay(true);
        pres.on("data", (chunk) => res.write(chunk));
        pres.on("end", () => res.end());
        pres.on("error", () => res.end());
        return;
      }
      pres.pipe(res);
    }
  );
  preq.setNoDelay(true);
  preq.on("error", (e) => {
    if (!res.headersSent) res.writeHead(502, { "content-type": "application/json" });
    res.end(JSON.stringify({ error: "upstream_unreachable", message: e.message }));
  });
  req.pipe(preq);
  req.on("aborted", () => preq.destroy());
}

// ---------- attachments ----------
function readBody(req, limit = 64 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let n = 0;
    req.on("data", (c) => {
      n += c.length;
      if (n > limit) {
        reject(new Error("payload too large"));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

function parseMultipart(buf, boundary) {
  const out = [];
  const sep = Buffer.from("--" + boundary);
  let start = buf.indexOf(sep);
  while (start !== -1) {
    const next = buf.indexOf(sep, start + sep.length);
    if (next === -1) break;
    const part = buf.slice(start + sep.length + 2, next - 2);
    const headEnd = part.indexOf("\r\n\r\n");
    if (headEnd !== -1) {
      const head = part.slice(0, headEnd).toString();
      const body = part.slice(headEnd + 4);
      const fn = /filename="([^"]*)"/i.exec(head);
      const nm = /name="([^"]*)"/i.exec(head);
      out.push({ filename: fn ? fn[1] : null, name: nm ? nm[1] : null, data: body });
    }
    start = next;
  }
  return out;
}

function json(res, code, obj) {
  res.writeHead(code, { "content-type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(obj));
}

function toFileUri(p) {
  const norm = p.replace(/\\/g, "/");
  return "file://" + (/^[A-Za-z]:/.test(norm) ? "/" + norm : norm);
}

async function handleUpload(req, res) {
  try {
    const ct = req.headers["content-type"] || "";
    const m = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(ct);
    if (!m) throw new Error("missing multipart boundary");
    const body = await readBody(req);
    const parts = parseMultipart(body, (m[1] || m[2]).trim());
    const saved = [];
    for (const p of parts) {
      if (!p.filename) continue;
      const safe = path.basename(p.filename).replace(/[^\w.\-() ]+/g, "_") || "file";
      const dir = path.join(
        UPLOADS,
        Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8)
      );
      fs.mkdirSync(dir, { recursive: true });
      const dest = path.join(dir, safe);
      fs.writeFileSync(dest, p.data);
      saved.push({
        name: safe,
        path: dest,
        size: p.data.length,
        uri: toFileUri(dest),
        preview: "/gui/file?path=" + encodeURIComponent(dest),
      });
    }
    json(res, 200, { data: saved });
  } catch (e) {
    json(res, 400, { error: e.message });
  }
}

function serveLocalFile(req, res) {
  const u = new URL(req.url, "http://x");
  const p = u.searchParams.get("path");
  if (!p) return notFound(res);
  fs.readFile(p, (err, data) => {
    if (err) return notFound(res);
    res.writeHead(200, {
      "content-type": MIME[path.extname(p).toLowerCase()] || "application/octet-stream",
      "cache-control": "max-age=3600",
    });
    res.end(data);
  });
}

function listDir(req, res) {
  const u = new URL(req.url, "http://x");
  const dir = path.resolve(u.searchParams.get("path") || os.homedir());
  try {
    const entries = fs
      .readdirSync(dir, { withFileTypes: true })
      .filter((e) => e.isDirectory() && !e.name.startsWith("."))
      .map((e) => ({ name: e.name, path: path.join(dir, e.name) }))
      .slice(0, 800);
    json(res, 200, { data: { dir, parent: path.dirname(dir), entries } });
  } catch (e) {
    /* "not a folder" is an answer the UI asks for on purpose — it checks every
       session directory before using it — so it is a 200 with no data, not an
       error, and the browser console stays readable. */
    json(res, 200, { data: null, error: e.message });
  }
}

/* Resolve a folder name picked in the browser's native dialog to full paths.
   The dialog only reveals names, so look in the places the user works:
   home, Desktop, the server cwd, and recent session folders (sent as hints),
   plus one level below each. */
async function handleResolveDir(req, res) {
  try {
    const body = JSON.parse((await readBody(req, 256 * 1024)).toString() || "{}");
    const name = String(body.name || "").trim();
    if (!name || /[\\/]/.test(name)) throw new Error("bad folder name");
    const hints = Array.isArray(body.hints) ? body.hints.filter((x) => typeof x === "string") : [];
    const roots = [];
    const addRoot = (r) => {
      if (r && !roots.some((x) => x.toLowerCase() === String(r).toLowerCase())) roots.push(r);
    };
    addRoot(os.homedir());
    addRoot(path.join(os.homedir(), "Desktop"));
    addRoot(CWD);
    for (const h of hints.slice(0, 20)) {
      addRoot(h);
      addRoot(path.dirname(h));
    }
    const want = name.toLowerCase();
    const seen = new Set();
    const matches = [];
    const hit = (full) => {
      const k = full.toLowerCase();
      if (!seen.has(k)) {
        seen.add(k);
        matches.push(full);
      }
    };
    const kidsOf = (dir, limit) => {
      try {
        return fs.readdirSync(dir, { withFileTypes: true }).slice(0, limit);
      } catch {
        return [];
      }
    };
    for (const root of roots) {
      for (const k of kidsOf(root, 500)) {
        if (!k.isDirectory() || k.name.startsWith(".")) continue;
        if (k.name.toLowerCase() === want) hit(path.join(root, k.name));
      }
      if (matches.length >= 10) break;
      for (const k of kidsOf(root, 120)) {
        if (!k.isDirectory() || k.name.startsWith(".") || matches.length >= 10) continue;
        for (const s of kidsOf(path.join(root, k.name), 120)) {
          if (!s.isDirectory() || s.name.startsWith(".")) continue;
          if (s.name.toLowerCase() === want) hit(path.join(root, k.name, s.name));
          if (matches.length >= 10) break;
        }
      }
      if (matches.length >= 10) break;
    }
    json(res, 200, { data: { name, matches } });
  } catch (e) {
    json(res, 400, { error: e.message });
  }
}

// ---------- boot ----------
function openBrowser(url) {
  try {
    if (process.platform === "win32")
      spawn("cmd", ["/c", "start", "", url], { stdio: "ignore", detached: true }).unref();
    else if (process.platform === "darwin")
      spawn("open", [url], { stdio: "ignore", detached: true }).unref();
    else spawn("xdg-open", [url], { stdio: "ignore", detached: true }).unref();
  } catch {}
}

function probe(port) {
  return new Promise((resolve) => {
    const req = http.get({ hostname: HOST, port, path: "/gui/info", timeout: 1200 }, (res) => {
      let b = "";
      res.on("data", (c) => (b += c));
      res.on("end", () => {
        try { resolve(JSON.parse(b).upstream ? true : false); } catch { resolve(false); }
      });
    });
    req.on("error", () => resolve(false));
    req.on("timeout", () => { req.destroy(); resolve(false); });
  });
}

(async () => {
  // already running on this port? just open it.
  if (await probe(GUI_PORT)) {
    const url = "http://" + HOST + ":" + GUI_PORT;
    process.stdout.write("opencode gui is already running -> " + url + "\n");
    if (!NO_OPEN) openBrowser(url);
    process.exit(0);
  }

  if (!upstream) {
    process.stdout.write("starting opencode server...\n");
    upstream = await startServer();
  }
  process.stdout.write("opencode api: " + upstream + "\n");

  const server = http.createServer((req, res) => {
    const p = req.url.split("?")[0];
    if (p.startsWith("/oc/")) return proxy(req, res);
    if (p === "/gui/upload" && req.method === "POST") return handleUpload(req, res);
    if (p === "/gui/file") return serveLocalFile(req, res);
    if (p === "/gui/dirs") return listDir(req, res);
    if (p === "/gui/resolve-dir" && req.method === "POST") return handleResolveDir(req, res);
    if (p === "/gui/auto-title" && req.method === "POST") return handleAutoTitle(req, res);
    if (p === "/gui/info")
      return json(res, 200, { upstream, cwd: CWD, home: os.homedir(), sep: path.sep });
    return serveStatic(req, res);
  });
  server.on("clientError", (e, sock) => sock.destroy());

  let port = GUI_PORT;
  server.on("error", (e) => {
    if (e.code === "EADDRINUSE" && port < GUI_PORT + 12) {
      port += 1;
      setTimeout(() => server.listen(port, HOST), 60);
    } else {
      console.error("cannot listen:", e.message);
      shutdown();
    }
  });
  server.on("listening", () => {
    const url = "http://" + HOST + ":" + port;
    process.stdout.write("\n  opencode gui  ->  " + url + "\n\n");
    if (!NO_OPEN) openBrowser(url);
  });
  server.listen(port, HOST);
})().catch((e) => {
  console.error("failed to start:", e.message);
  process.exit(1);
});
