<#
  opencode gui - installer

  Installs the GUI beside the opencode you already have, and puts a shim on
  PATH so `opencode gui` starts it. Everything else goes to the real opencode.

  Run:   powershell -ExecutionPolicy Bypass -File install.ps1
  Flags: -Dir <path>   install somewhere else
         -NoPath       do not touch PATH
#>

[CmdletBinding()]
param(
  [string]$Dir = (Join-Path $env:LOCALAPPDATA 'Programs\opencode-gui'),
  [switch]$NoPath
)

$ErrorActionPreference = 'Stop'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path

function Say  ($m) { Write-Host "  $m" }
function Ok   ($m) { Write-Host "  $m" -ForegroundColor Green }
function Warn ($m) { Write-Host "  $m" -ForegroundColor Yellow }
function Die  ($m) { Write-Host "  $m" -ForegroundColor Red; exit 1 }

Write-Host ""
Write-Host "opencode gui - install" -ForegroundColor Cyan
Write-Host ""

# ---------- payload ----------
# Next to a built package the app sits in .\app; in the repo it is ..\ (Source Code).
$App = Join-Path $Here 'app'
if (-not (Test-Path (Join-Path $App 'server.mjs'))) { $App = Split-Path -Parent $Here }
if (-not (Test-Path (Join-Path $App 'server.mjs'))) {
  Die "server.mjs not found. Run this script from the installer folder."
}

# ---------- node ----------
$node = Get-Command node -CommandType Application -ErrorAction SilentlyContinue
if (-not $node) { Die "Node.js is not on PATH. Install Node 18+ and run this again." }
$nodeVer = (& node --version) -replace '^v',''
if ([int]($nodeVer.Split('.')[0]) -lt 18) { Die "Node $nodeVer is too old. Node 18+ is needed." }
Ok "node $nodeVer"

# ---------- the real opencode ----------
$BinDir = Join-Path $Dir 'bin'

# A shim on PATH is not the real thing. Any script that launches server.mjs is
# one of ours - skip it, or the GUI ends up calling itself.
function Test-IsShim([string]$p) {
  if (-not $p) { return $false }
  if ($p -like "$BinDir*") { return $true }
  if ((Get-Item $p).Length -gt 8kb) { return $false }   # a real binary, not a script
  try { return (Get-Content $p -Raw -ErrorAction Stop) -match 'server\.mjs|OPENCODE_GUI_SHIM' }
  catch { return $false }
}

$real = $null
$found = Get-Command opencode -CommandType Application -All -ErrorAction SilentlyContinue |
         Where-Object { $_.Source -and -not (Test-IsShim $_.Source) }
if ($found) { $real = $found[0].Source }
if (-not $real) {
  foreach ($c in @(
      (Join-Path $env:APPDATA 'npm\opencode.cmd'),
      (Join-Path $env:USERPROFILE '.opencode\bin\opencode.exe'),
      (Join-Path $env:LOCALAPPDATA 'Programs\opencode\opencode.exe'))) {
    if (Test-Path $c) { $real = $c; break }
  }
}
if (-not $real) { Die "opencode was not found. Install opencode first, then run this again." }
Ok "opencode  $real"

# ---------- copy ----------
if (Test-Path (Join-Path $Dir 'app')) { Remove-Item (Join-Path $Dir 'app') -Recurse -Force }
New-Item -ItemType Directory -Force -Path (Join-Path $Dir 'app') | Out-Null
New-Item -ItemType Directory -Force -Path $BinDir | Out-Null
Copy-Item (Join-Path $App 'server.mjs') (Join-Path $Dir 'app\server.mjs') -Force
Copy-Item (Join-Path $App 'public')     (Join-Path $Dir 'app\public') -Recurse -Force
if (Test-Path (Join-Path $App 'README.md')) {
  Copy-Item (Join-Path $App 'README.md') (Join-Path $Dir 'README.md') -Force
}
Ok "files     $Dir"

$gui = (Join-Path $Dir 'app\server.mjs')

# ---------- shims ----------
# cmd.exe / anything that runs a .cmd
@"
@echo off
rem OPENCODE_GUI_SHIM
setlocal
set "OPENCODE_BIN=$real"
set "OC_GUI=$gui"
if /I "%~1"=="gui" goto :gui
"$real" %*
exit /b %errorlevel%
:gui
node "%OC_GUI%" %*
exit /b %errorlevel%
"@ | Set-Content -Path (Join-Path $BinDir 'opencode.cmd') -Encoding ascii

# PowerShell
$realPs = [IO.Path]::ChangeExtension($real, '.ps1')
if (-not (Test-Path $realPs)) { $realPs = $real }
@"
#!/usr/bin/env pwsh
# OPENCODE_GUI_SHIM
`$env:OPENCODE_BIN = '$real'
`$gui = '$gui'
if (`$args.Count -gt 0 -and `$args[0] -ieq 'gui') {
  & node `$gui @args
  exit `$LASTEXITCODE
}
& '$realPs' @args
exit `$LASTEXITCODE
"@ | Set-Content -Path (Join-Path $BinDir 'opencode.ps1') -Encoding utf8

# Git Bash / sh
$realSh = ($real -replace '\\','/') -replace '\.(cmd|ps1)$',''
$guiSh  = $gui -replace '\\','/'
$sh = @"
#!/bin/sh
# OPENCODE_GUI_SHIM: intercept "opencode gui", pass everything else through.
export OPENCODE_BIN="$real"
if [ "`$1" = "gui" ]; then
  exec node "$guiSh" "`$@"
fi
exec "$realSh" "`$@"
"@
[IO.File]::WriteAllText((Join-Path $BinDir 'opencode'), ($sh -replace "`r`n","`n"))

# a name that always works, whatever PATH order is
@"
@echo off
rem OPENCODE_GUI_SHIM
setlocal
set "OPENCODE_BIN=$real"
node "$gui" %*
exit /b %errorlevel%
"@ | Set-Content -Path (Join-Path $BinDir 'opencode-gui.cmd') -Encoding ascii

Copy-Item (Join-Path $Here 'uninstall.ps1') (Join-Path $Dir 'uninstall.ps1') -Force
Ok "shims     $BinDir"

# ---------- PATH ----------
if (-not $NoPath) {
  $userPath = [Environment]::GetEnvironmentVariable('Path','User')
  $parts = @($userPath -split ';' | Where-Object { $_ -and $_.TrimEnd('\') -ne $BinDir.TrimEnd('\') })
  [Environment]::SetEnvironmentVariable('Path', (@($BinDir) + $parts) -join ';', 'User')
  $env:Path = $BinDir + ';' + $env:Path
  Ok "PATH      $BinDir (first)"

  # A machine-wide opencode wins over any user PATH entry. Say so rather than lie.
  $winner = (Get-Command opencode -CommandType Application -ErrorAction SilentlyContinue).Source
  if ($winner -and $winner -notlike "$BinDir*") {
    Warn "`"$winner`" still answers first on PATH."
    Warn "Use `"opencode-gui`" instead, or move $BinDir above it."
  }
} else {
  Warn "PATH not changed. Add $BinDir yourself, or run opencode-gui.cmd."
}

Write-Host ""
Ok "done. Open a new terminal and run:  opencode gui"
Write-Host ""
Say "uninstall:  powershell -ExecutionPolicy Bypass -File `"$Dir\uninstall.ps1`""
Write-Host ""
