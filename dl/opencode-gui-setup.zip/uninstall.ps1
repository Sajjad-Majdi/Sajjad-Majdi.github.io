<#
  opencode gui - uninstaller. Removes the shims, the PATH entry and the files.
  The real opencode is not touched.
#>

[CmdletBinding()]
param([string]$Dir = (Join-Path $env:LOCALAPPDATA 'Programs\opencode-gui'))

$ErrorActionPreference = 'Stop'
$BinDir = Join-Path $Dir 'bin'

Write-Host ""
Write-Host "opencode gui - uninstall" -ForegroundColor Cyan

$userPath = [Environment]::GetEnvironmentVariable('Path','User')
if ($userPath) {
  $parts = @($userPath -split ';' | Where-Object { $_ -and $_.TrimEnd('\') -ne $BinDir.TrimEnd('\') })
  if ($parts.Count -ne @($userPath -split ';' | Where-Object { $_ }).Count) {
    [Environment]::SetEnvironmentVariable('Path', ($parts -join ';'), 'User')
    Write-Host "  PATH entry removed" -ForegroundColor Green
  }
}

if (Test-Path $Dir) {
  # The script may be running from inside $Dir; move on and delete what we can.
  Get-ChildItem $Dir -Force | Where-Object { $_.Name -ne 'uninstall.ps1' } |
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item (Join-Path $Dir 'uninstall.ps1') -Force -ErrorAction SilentlyContinue
  Remove-Item $Dir -Recurse -Force -ErrorAction SilentlyContinue
  Write-Host "  files removed: $Dir" -ForegroundColor Green
}

Write-Host "  done. The real opencode is untouched." -ForegroundColor Green
Write-Host ""
